local player = game:GetService("Players").LocalPlayer
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local killLoop = false
local knifeLoop = false
local skillLoop = false
local killInterval = 0.1
local attackRange = 50
local allFunctionsEnabled = false
local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)

local Tab1 = Window:Tab({Title = "主要功能", Icon = "zap"})
local MainSection1 = Tab1:Section({Title = "杀戮", Icon = "swords", Opened = true})
Window:SelectTab(1)
MainSection1:Toggle({
    Title = "自动杀戮",
    Value = killLoop,
    Callback = function(Value)
        killLoop = Value
        if Value then
            task.spawn(function()
                while killLoop do
                    local success, err = pcall(function()
                        local character = player.Character
                        if character and character:FindFirstChild("HumanoidRootPart") then
                            local humanoidRootPart = character.HumanoidRootPart
                            local currentPosition = humanoidRootPart.Position
                            for i = 1, 10 do
                                local angle = math.rad(i * 36)
                                local offset = Vector3.new(math.cos(angle) * attackRange, 0, math.sin(angle) * attackRange)
                                local targetPosition = currentPosition + offset
                                local args = {
                                    [1] = "10016",
                                    [2] = "20",
                                    [3] = {},
                                    [4] = targetPosition
                                }
                                ReplicatedStorage.GameplayAbilitySystem.Remote.ClientApplyServerActivateGA:InvokeServer(unpack(args))
                            end
                        end
                    end)
                    if not success then
                        killLoop = false
                        WindUI:Notify({
                            Title = "错误",
                            Content = "杀戮无法运行",
                            Duration = 3,
                            Icon = "4483362458"
                        })
                        break
                    end
                    task.wait(killInterval)
                end
            end)
            WindUI:Notify({
                Title = "提示",
                Content = "自动杀戮已开启",
                Duration = 2,
                Icon = "4483362458"
            })
        else
            WindUI:Notify({
                Title = "提示",
                Content = "自动杀戮已关闭",
                Duration = 2,
                Icon = "4483362458"
            })
        end
    end
})

MainSection1:Toggle({
    Title = "自动砍刀(概率)",
    Value = knifeLoop,
    Callback = function(Value)
        knifeLoop = Value
        if Value then
            task.spawn(function()
                while knifeLoop do
                    local success, err = pcall(function()
                        local args = {
                            [1] = "10016",
                            [2] = "23",
                            [3] = {}
                        }
                        ReplicatedStorage.GameplayAbilitySystem.Remote.ClientApplyServerActivateGA:InvokeServer(unpack(args))
                    end)
                    if not success then
                        knifeLoop = false
                        WindUI:Notify({
                            Title = "错误",
                            Content = "自动砍刀模块无法使用，已自动关闭",
                            Duration = 3,
                            Icon = "4483362458"
                        })
                        break
                    end
                    task.wait(0.1)
                end
            end)
            WindUI:Notify({
                Title = "提示",
                Content = "自动砍刀已开启",
                Duration = 2,
                Icon = "4483362458"
            })
        else
            WindUI:Notify({
                Title = "提示",
                Content = "自动砍刀已关闭",
                Duration = 2,
                Icon = "4483362458"
            })
        end
    end
})

MainSection1:Toggle({
    Title = "自动一技能",
    Value = skillLoop,
    Callback = function(Value)
        skillLoop = Value
        if Value then
            task.spawn(function()
                while skillLoop do
                    local success, err = pcall(function()
                        local args = {
                            [1] = "10016",
                            [2] = "21",
                            [3] = {}
                        }
                        ReplicatedStorage.GameplayAbilitySystem.Remote.ClientApplyServerActivateGA:InvokeServer(unpack(args))
                    end)
                    if not success then
                        skillLoop = false
                        WindUI:Notify({
                            Title = "错误",
                            Content = "自动一技能模块无法使用，已自动关闭",
                            Duration = 3,
                            Icon = "4483362458"
                        })
                        break
                    end
                    task.wait(0.1)
                end
            end)
            WindUI:Notify({
                Title = "提示",
                Content = "自动一技能已开启",
                Duration = 2,
                Icon = "4483362458"
            })
        else
            WindUI:Notify({
                Title = "提示",
                Content = "自动一技能已关闭",
                Duration = 2,
                Icon = "4483362458"
            })
        end
    end
})

local SkillControlSection = Tab1:Section({Title = "技能控制", Icon = "settings", Opened = true})

SkillControlSection:Slider({
    Title = "杀戮攻击速度",
    Desc = "调整自动杀戮的攻击速度",
    Value = { 
        Min = 0.05,
        Max = 2,
        Default = 0.1,
    },
    Step = 0.05,
    Callback = function(Value)
        killInterval = Value
        WindUI:Notify({
            Title = "设置已更新",
            Content = "杀戮攻速: " .. Value .. "秒",
            Duration = 2,
            Icon = "4483362458"
        })
    end
})

SkillControlSection:Slider({
    Title = "攻击范围[50%无效]",
    Desc = "调整自动杀戮的攻击范围",
    Value = { 
        Min = 10,
        Max = 100,
        Default = 50,
    },
    Step = 5,
    Callback = function(Value)
        attackRange = Value
        WindUI:Notify({
            Title = "设置已更新",
            Content = "攻击距离: " .. Value .. "米",
            Duration = 2,
            Icon = "4483362458"
        })
    end
})

SkillControlSection:Toggle({
    Title = "一键全开",
    Value = allFunctionsEnabled,
    Callback = function(Value)
        if Value then
            killLoop = true
            knifeLoop = true
            skillLoop = true
            allFunctionsEnabled = true
            task.spawn(function()
                while killLoop do
                    local success1, err1 = pcall(function()
                        local character = player.Character
                        if character and character:FindFirstChild("HumanoidRootPart") then
                            local humanoidRootPart = character.HumanoidRootPart
                            local currentPosition = humanoidRootPart.Position
                            for i = 1, 10 do
                                local angle = math.rad(i * 36)
                                local offset = Vector3.new(math.cos(angle) * attackRange, 0, math.sin(angle) * attackRange)
                                local targetPosition = currentPosition + offset
                                local killArgs = {
                                    [1] = "10016",
                                    [2] = "20",
                                    [3] = {},
                                    [4] = targetPosition
                                }
                                ReplicatedStorage.GameplayAbilitySystem.Remote.ClientApplyServerActivateGA:InvokeServer(unpack(killArgs))
                            end
                        end
                    end)
                    if not success1 then
                        killLoop = false
                        WindUI:Notify({
                            Title = "错误",
                            Content = "自动杀戮模块无法运行",
                            Duration = 3,
                            Icon = "4483362458"
                        })
                        break
                    end
                    task.wait(killInterval)
                end
            end)
            task.spawn(function()
                while knifeLoop do
                    local success2, err2 = pcall(function()
                        local knifeArgs = {[1] = "10016", [2] = "23", [3] = {}}
                        ReplicatedStorage.GameplayAbilitySystem.Remote.ClientApplyServerActivateGA:InvokeServer(unpack(knifeArgs))
                    end)
                    if not success2 then
                        knifeLoop = false
                        WindUI:Notify({
                            Title = "错误",
                            Content = "自动砍刀模块无法使用，已自动关闭",
                            Duration = 3,
                            Icon = "4483362458"
                        })
                        break
                    end
                    task.wait(0.1)
                end
            end)
            task.spawn(function()
                while skillLoop do
                    local success3, err3 = pcall(function()
                        local skillArgs = {[1] = "10016", [2] = "21", [3] = {}}
                        ReplicatedStorage.GameplayAbilitySystem.Remote.ClientApplyServerActivateGA:InvokeServer(unpack(skillArgs))
                    end)
                    if not success3 then
                        skillLoop = false
                        WindUI:Notify({
                            Title = "错误",
                            Content = "自动一技能模块无法运行",
                            Duration = 3,
                            Icon = "4483362458"
                        })
                        break
                    end
                    task.wait(0.1)
                end
            end)
            WindUI:Notify({
                Title = "提示",
                Content = "所有功能已开启",
                Duration = 3,
                Icon = "4483362458"
            })
        else
            killLoop = false
            knifeLoop = false
            skillLoop = false
            allFunctionsEnabled = false
            WindUI:Notify({
                Title = "提示",
                Content = "所有功能已关闭",
                Duration = 3,
                Icon = "4483362458"
            })
        end
    end
})

SkillControlSection:Button({
    Title = "一键关闭所有",
    Icon = "power",
    Callback = function()
        killLoop = false
        knifeLoop = false
        skillLoop = false
        allFunctionsEnabled = false
        WindUI:Notify({
            Title = "666",
            Content = "已关闭所有功能",
            Duration = 3,
            Icon = "4483362458"
        })
    end
})