local aimbotScript = nil
local aimbotEnabled = false

local killerWeapons = {["CharcoalSteel JS-22"] = true, ["Hammer n Bullet"] = true, ["Pretty Pink RR-LCP"] = true, ["JS2-BondsDerringy"] = true, ["JTS-225"] = true, ["JTS-225 Monochrome"] = true, ["JTS-225 poly"] = true, ["JTS-225 Party cannon"] = true, ["GILDED"] = true, ["Kamatov"] = true, ["JS2-Derringy"] = true, ["JS-22"] = true, ["NGO"] = true, ["Throwing Dagger"] = true, ["SoundMaker"] = true, ["SoundMakerSlower"] = true, ["RR-LightCompactPistolS"] = true, ["J9-Mereta"] = true, ["RY's GG-17"] = true, ["RR-LCP"] = true, ["JS1 Competitor"] = true, ["AT's KAR15"] = true, ["VK's ANKM"] = true, ["Clothed Sawn-off"] = true, ["Sawn-off"] = true, ["Clothed Rosen-Obrez"] = true, ["Rosen-Obrez"] = true, ["GraySteel K1911"] = true, ["DarkSteel K1911"] = true, ["SilverSteel K1911"] = true, ["K1911"] = true, ["ZZ-90"] = true, ["SKORPION"] = true, ["Mares Leg"] = true, ["RR-LightCompactPistol"] = true, ["KamatovS"] = true, ["Throwing Tomahawk"] = true, ["Throwing Kunai"] = true, ["ChromeSlide Turqoise RR-LCP"] = true, ["JS-1 CYCLOPS"] = true, ["THUMPA"] = true, ["LUT-E 'KRUS'"] = true}
local vigilanteWeapons = {["Beagle"] = true, ["IZVEKH-412"] = true, ["SilverSteel RR-Snubby"] = true, ["RR-Snubby"] = true, ["ZKZ-Obrez"] = true, ["Clothed ZKZ-Obrez"] = true, ["Buxxberg-COMPACT"] = true, ["pretty pink Buxxberg-COMPACT"] = true, ["JS-5A-OBREZ"] = true, ["GG-17"] = true, ["J9-M"] = true, ["J9-Meretta"] = true, ["Pretty Pink GG-17"] = true, ["GG-17 TAN"] = true, ["GG-17 GILDED"] = true, ["RR-Snubby GILDED"] = true, ["HWISSH-226"] = true, ["Dual Elites"] = true, ["ZKZ-Obrez10"] = true}

local Players = game:GetService("Players")
local lp = Players.LocalPlayer
local Workspace = game:GetService("Workspace")
local NPCSFolder = Workspace:WaitForChild("NPCSFolder")
local BloodFolder = Workspace:WaitForChild("BloodFolder")

local espEnabled = false
local playersMatchingHints = {}

local function clearOldStuff(character)
    if not character then return end
    local old = character:FindFirstChild("RoleHighlight")
    if old then old:Destroy() end
    local head = character:FindFirstChild("Head")
    if head then local t = head:FindFirstChild("RoleBillboard") if t then t:Destroy() end end
end

local function tagPlayer(player, color, label)
    if not player.Character then return end
    clearOldStuff(player.Character)
    local highlight = Instance.new("Highlight", player.Character)
    highlight.Name = "RoleHighlight"
    highlight.FillColor = color
    highlight.FillTransparency = 0.5
    local head = player.Character:FindFirstChild("Head")
    if head then
        local bb = Instance.new("BillboardGui", head)
        bb.Name = "RoleBillboard"
        bb.Size = UDim2.new(0,100,0,20)
        bb.StudsOffset = Vector3.new(0,2,0)
        bb.AlwaysOnTop = true
        local l = Instance.new("TextLabel", bb)
        l.Size = UDim2.new(1,0,1,0)
        l.BackgroundTransparency = 1
        l.Text = label
        l.TextColor3 = color
        l.TextScaled = true
    end
end

local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)

local PlayerTab = Window:Tab({Title = "透视功能", Icon = "users"})
Window:SelectTab(1)
PlayerTab:Section({Title = "ESP"}):Toggle({
    Title = "开启 ESP",
    Value = false,
    Callback = function(state)
        espEnabled = state
        if state then
            task.spawn(function()
                while espEnabled do
                    pcall(function()
                        for _, p in pairs(Players:GetPlayers()) do
                            if p ~= lp and p.Character then
                                local tools = {}
                                for _, t in pairs(p.Backpack:GetChildren()) do tools[t.Name] = true end
                                for _, t in pairs(p.Character:GetChildren()) do if t:IsA("Tool") then tools[t.Name] = true end end
                                
                                local found = false
                                for n, _ in pairs(tools) do
                                    if killerWeapons[n] then tagPlayer(p, Color3.new(1,0,0), "杀手") found = true break end
                                    if vigilanteWeapons[n] then tagPlayer(p, Color3.new(0,1,1), "警官") found = true break end
                                end
                                if not found then tagPlayer(p, Color3.new(0,1,0), "中立") end
                            end
                        end
                    end)
                    task.wait(1)
                end
            end)
        else
            for _, p in pairs(Players:GetPlayers()) do clearOldStuff(p.Character) end
        end
    end
})

local AimTab = Window:Tab({Title = "自瞄功能", Icon = "target"})
local AimSection = AimTab:Section({Title = "自瞄设置", Opened = true})

AimSection:Button({
    Title = "第一步：加载自瞄",
    Desc = "必须先点击此按钮自瞄才有效",
    Callback = function()
        pcall(function()
            aimbotScript = loadstring(game:HttpGet("https://raw.githubusercontent.com/yisanll/yisani/refs/heads/main/aimbot.lua.txt"))()
            if aimbotScript and aimbotScript.Init then
                aimbotScript:Init()
                aimbotEnabled = true
                WindUI:Notify({Title = "加载成功", Content = "自瞄已启动", Duration = 3})
            else
                WindUI:Notify({Title = "失败", Content = "外部脚本未能返回有效对象", Duration = 3})
            end
        end)
    end
})

AimSection:Toggle({
    Title = "开启自瞄",
    Value = false,
    Callback = function(v)
        if aimbotScript and aimbotScript.SetEnabled then
            aimbotScript:SetEnabled(v)
        end
    end
})

AimSection:Toggle({
    Title = "检查墙壁",
    Value = false,
    Callback = function(v)
        if aimbotScript and aimbotScript.SetWallHack then
            aimbotScript:SetWallHack(v)
        end
    end
})

AimSection:Slider({
    Title = "FOV 范围 ",
    Step = 1,
    Value = {Min = 10, Max = 500, Default = 100},
    Callback = function(v)
        if aimbotScript and aimbotScript.SetPOVConfig then
            local config = aimbotScript:GetPOVConfig() or {}
            config.FOV = v
            aimbotScript:SetPOVConfig(config)
        end
    end
})

AimSection:Slider({
    Title = "自瞄平滑度",
    Step = 0.1,
    Value = {Min = 1, Max = 10, Default = 4},
    Callback = function(v)
        if aimbotScript and aimbotScript.SetPOVConfig then
            local config = aimbotScript:GetPOVConfig() or {}
            config.Smoothness = v -- 视外部脚本参数名而定
            aimbotScript:SetPOVConfig(config)
        end
    end
})

AimSection:ColorPicker({
    Title = "FOV 圆圈颜色",
    Default = Color3.fromRGB(255, 0, 0),
    Callback = function(color)
        if aimbotScript and aimbotScript.SetPOVConfig then
            local config = aimbotScript:GetPOVConfig() or {}
            config.Color = color
            aimbotScript:SetPOVConfig(config)
        end
    end
})

local MiscTab = Window:Tab({Title = "不知道", Icon = "plus"})
MiscTab:Section({Title = "锁定"}):Button({
    Title = "视角锁定",
    Callback = function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/yisanll/yisani/refs/heads/main/locking.lua.txt"))()
    end
})

WindUI:Notify({Title = "提示", Content = "自瞄请务必先点击加载按钮！", Duration = 5})