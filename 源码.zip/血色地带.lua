local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)
local CombatTab = Window:Tab({ Title = '功能', Icon = 'swords' })
Window:SelectTab(1)

local v1 = game:GetService("Players")
local v2 = v1.LocalPlayer
local v3 = true   
local v28 = false 
local v4 = 0.05  
local _G_AutoKill = false 

local function v5(v6, v7)
    if not v3 then return true end
    local v8 = RaycastParams.new()
    v8.FilterType = Enum.RaycastFilterType.Exclude
    v8.FilterDescendantsInstances = {v2.Character, workspace.CurrentCamera}
    local v9 = v6.Position - v7
    local v10 = workspace:Raycast(v7, v9, v8)
    if v10 and v10.Instance:IsDescendantOf(v6.Parent) then
        return true
    end
    return false
end

local function v11(v12)
    return v12:FindFirstChildOfClass("ForceField") ~= nil
end

task.spawn(function()
    while true do
        task.wait(v4)
        
        if not _G_AutoKill then continue end
        
        local v13 = workspace.CurrentCamera
        if not v2.Character then continue end
        
        local v14 = v2.Character:FindFirstChildOfClass("Tool")
        if not v14 then continue end
        
        local v15 = v14:FindFirstChild("FireWeapon")
        local v16 = v14:FindFirstChild("GunHit")
        if not v15 or not v16 then continue end

        local v17 = nil
        local v18 = math.huge
        local v19 = v13.CFrame.Position

        -- 寻找目标
        for _, v20 in pairs(workspace:GetDescendants()) do
            if v20:IsA("Humanoid") and v20.Health > 0 and v20.Parent ~= v2.Character then
                local v21 = v20.Parent
                local v22 = v21:FindFirstChild("Head") or v21:FindFirstChild("HumanoidRootPart")
                if v22 and not v11(v21) then
                    local v23 = v1:GetPlayerFromCharacter(v21)
                    if v23 and v28 then
                        if not (v2.Neutral or v23.Team ~= v2.Team) then continue end
                    end
                    
                    local v24 = (v22.Position - (v2.Character.HumanoidRootPart and v2.Character.HumanoidRootPart.Position or Vector3.new())).Magnitude
                    if v24 < v18 and v5(v22, v19) then
                        v18 = v24
                        v17 = {h = v20, p = v21, head = v22}
                    end
                end
            end
        end

        if v17 then
            local v25 = v17.head.Position
            local v26 = (v25 - v19).Magnitude
            local v27 = tick()

            v15:FireServer(v27)
            v16:FireServer(v27, {
                {
                    ["Normal"] = Vector3.new(0, 1, 0),
                    ["Position"] = v25,
                    ["Instance"] = v17.head,
                    ["Material"] = Enum.Material.Plastic,
                    ["Distance"] = v26
                }
            })
        end
    end
end)

CombatTab:Section({ Title = "功能" })

CombatTab:Toggle({
    Title = "杀戮光环",
    Value = false,
    Callback = function(state)
        _G_AutoKill = state
        WindUI:Notify({
            Title = "提示",
            Content = state and "已启用" or "已停用",
            Duration = 2,
            Icon = state and "check-circle" or "x-circle"
        })
    end
})
