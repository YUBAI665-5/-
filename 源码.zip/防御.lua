local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local RS = game:GetService("ReplicatedStorage")
local LocalPlayer = Players.LocalPlayer
local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

Window:Tag({
    Title = "lyy",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)
local borderEnabled = true
local animationSpeed = 3
local currentColorScheme = "PurpleBlue"
local FOV_Enabled = false
local FOV_Radius = 150
local FOV_Circle = Drawing.new("Circle")
FOV_Circle.Transparency = 1
FOV_Circle.Thickness = 1
FOV_Circle.Color = Color3.fromRGB(255, 255, 255)
FOV_Circle.Filled = false
FOV_Circle.Visible = false

local COLOR_SCHEMES = {
    ["PurpleBlue"] = {type = "duo", color1 = Color3.fromHex("#5A38FF"), color2 = Color3.fromHex("#36D1FF")}
}

local colorSchemeNames = {}
for name, _ in pairs(COLOR_SCHEMES) do
    table.insert(colorSchemeNames, name)
end
table.sort(colorSchemeNames)

local function ensureBlurElement()
    local mainFrame = Window.UIElements and Window.UIElements.Main
    if not mainFrame then return end
    local blur = mainFrame:FindFirstChild("Blur")
    if not blur then
        blur = Instance.new("ImageLabel")
        blur.Name = "Blur"
        blur.Size = UDim2.new(1, 0, 1, 0)
        blur.Position = UDim2.new(0, 0, 0, 0)
        blur.BackgroundTransparency = 1
        blur.Image = "rbxasset://textures/ui/GuiImagePlaceholder.png"
        blur.ImageTransparency = 0.2
        blur.ZIndex = 0
        blur.Parent = mainFrame
    end
    return blur
end

local function getColorForScheme(scheme, time)
    local data = COLOR_SCHEMES[scheme]
    if data.type == "rainbow" then
        local hue = (time * 0.5) % 1
        return Color3.fromHSV(hue, 1, 1)
    elseif data.type == "duo" then
        local t = (math.sin(time * 2) + 1) / 2
        return data.color1:Lerp(data.color2, t)
    end
    return Color3.new(1,1,1)
end

local function b(c, d, e)
    d = d or Color3.fromRGB(100, 150, 255)
    e = e or 0.1
    local f = c.UIElements and c.UIElements.Main or c.Frame or c.Gui or c
    if not f then return false end
    local g = f:FindFirstChild("Blur", true)
    if g and g:IsA("ImageLabel") then
        g.ImageColor3 = d
        g.ImageTransparency = e
        return true
    end
    local h = f:FindFirstChild("Shadow", true)
    if h and h:IsA("ImageLabel") then
        h.ImageColor3 = d
        h.ImageTransparency = e
        return true
    end
    return false
end

local borderConnection = nil

local function startBorderAnimation()
    if borderConnection then
        borderConnection:Disconnect()
        borderConnection = nil
    end
    if not borderEnabled then return end
    ensureBlurElement()
    borderConnection = RunService.Heartbeat:Connect(function()
        local mainFrame = Window.UIElements and Window.UIElements.Main
        if not mainFrame or not mainFrame.Visible then return end
        local time = tick() * animationSpeed
        local color = getColorForScheme(currentColorScheme, time)
        b(Window, color, 0.2)
    end)
end

local function stopBorderAnimation()
    if borderConnection then
        borderConnection:Disconnect()
        borderConnection = nil
    end
end

local function setupVisibilityListener()
    local mainFrame = Window.UIElements and Window.UIElements.Main
    if not mainFrame then
        task.spawn(function()
            repeat task.wait() until Window.UIElements and Window.UIElements.Main
            setupVisibilityListener()
        end)
        return
    end
    if mainFrame.Visible and borderEnabled then
        startBorderAnimation()
    elseif not mainFrame.Visible then
        stopBorderAnimation()
    end
    mainFrame:GetPropertyChangedSignal("Visible"):Connect(function()
        if mainFrame.Visible and borderEnabled then
            startBorderAnimation()
        else
            stopBorderAnimation()
        end
    end)
end

setupVisibilityListener()

Window:OnClose(function()
    stopBorderAnimation()
end)

local RemotePath = "\224\182\189\224\183\128\224\182\158\224\182\169"
local DamageRemote = RS:WaitForChild("Events"):WaitForChild(RemotePath, 10)

local WeaponConfigs = {
    {Name = "DB Shotgun", WeaponName = "DB Shotgun", Normal = Vector3.new(0.9340000152587891, -0.289000004529953, -0.20800000429153442), hS = 2.4494898319244385, Arg3 = 1, Arg4 = false},
    {Name = "Stealth Pistol", WeaponName = "USP", Normal = Vector3.new(0.871999979019165, 0.47099998593330383, -0.1379999965429306), hS = 2.4494898319244385, Arg3 = 1, Arg4 = false},
    {Name = "Auto Pistol", WeaponName = "TEC-9", Normal = Vector3.new(0.8489999771118164, 0.19699999690055847, 0.49000000953674316), hS = 2.4494898319244385, Arg3 = 1, Arg4 = false},
    {Name = "Magnum Pistol", WeaponName = "Deagle", Normal = Vector3.new(0.8669999837875366, -0.029999999329447746, 0.49799999594688416), hS = 3, Arg3 = 1, Arg4 = false},
    {Name = "Buckshot Shotgun", WeaponName = "M77E", Normal = Vector3.new(-0.847000002861023, 0.10000000149011612, -0.5220000147819519), hS = 3, Arg3 = 1, Arg4 = true},
    {Name = "Stealth SMG", WeaponName = "Vector", Normal = Vector3.new(-0.6850000023841858, -0.13199999928474426, 0.7170000076293945), hS = 3, Arg3 = 1, Arg4 = false},
    {Name = "Compact Shotgun", WeaponName = "MAG-7", Normal = Vector3.new(0.8970000147819519, 0.05400000140070915, -0.4399999976158142), hS = 2.4494898319244385, Arg3 = 1, Arg4 = false},
    {Name = "Striker SMG", WeaponName = "UMP-45", Normal = Vector3.new(0.4230000078678131, -0.6269999742507935, -0.6539999842643738), hS = 2.4494898319244385, Arg3 = false, Arg4 = true},
    {Name = "Bullpup SMG", WeaponName = "P90", Normal = Vector3.new(0.10499999672174454, -0.11400000005960464, -0.9879999756813049), hS = 3, Arg3 = 1, Arg4 = false},
    {Name = "Soviet Rifle", WeaponName = "AK-47", Normal = Vector3.new(0.8040000200271606, 0.5120000243186951, 0.30300000309944153), hS = 3, Arg3 = 1, Arg4 = false},
    {Name = "Lightweight Sniper", WeaponName = "M40", Normal = Vector3.new(-0.9660000205039978, -0.2529999911785126, 0.061000000685453415), hS = 2.4494898319244385, Arg3 = 1, Arg4 = true},
    {Name = "Stealth Rifle", WeaponName = "M4A1", Normal = Vector3.new(0.3529999852180481, -0.1459999978542328, 0.9240000247955322), hS = 3, Arg3 = 1, Arg4 = false},
    {Name = "Scoped Rifle", WeaponName = "AUG", Normal = Vector3.new(-0.5199999809265137, 0.007000000216066837, -0.8539999723434448), hS = 3, Arg3 = 1, Arg4 = false, Noscope = true},
    {Name = "Heavy Sniper", WeaponName = "Barrett", Normal = Vector3.new(-0.32100000977516174, -0.009999999776482582, 0.9470000267028809), hS = 3, Arg3 = 1, Arg4 = false}
}

local WeaponNames = {}
for _, config in ipairs(WeaponConfigs) do
    table.insert(WeaponNames, config.Name)
end

local SelectedWeapon = WeaponConfigs[1]
local TargetPart = "Head"
local Running = false
local TeamCheck = false
local TracerEnabled = true
local TracerDuration = 0.2

local ESP_Enabled = false

local function isSameTeam(plr)
    if not TeamCheck then return false end
    if plr == LocalPlayer then return true end
    
    local same = false
    pcall(function() if LocalPlayer.Team and plr.Team and LocalPlayer.Team == plr.Team then same = true end end)
    if not same then
        pcall(function() if LocalPlayer:GetAttribute("Team") and plr:GetAttribute("Team") and LocalPlayer:GetAttribute("Team") == plr:GetAttribute("Team") then same = true end end)
    end
    return same
end

local function updateESP(enabled)
    ESP_Enabled = (enabled ~= nil) and enabled or ESP_Enabled
    for _, player in ipairs(Players:GetPlayers()) do
        if player == LocalPlayer or not player.Character then continue end
        local highlight = player.Character:FindFirstChild("PlayerHighlight")
        if ESP_Enabled and not isSameTeam(player) then
            if not highlight then
                highlight = Instance.new("Highlight")
                highlight.Name = "PlayerHighlight"
                highlight.FillColor = Color3.fromRGB(255, 0, 0)
                highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
                highlight.FillTransparency = 0.5
                highlight.Parent = player.Character
            end
            highlight.Enabled = true
        else
            if highlight then highlight.Enabled = false end
        end
    end
end

local function CreateTracer(startPos, endPos)
    if not TracerEnabled then return end
    
    local part = Instance.new("Part")
    part.Parent = workspace
    part.Anchored = true
    part.CanCollide = false
    part.Transparency = 1
    part.Size = Vector3.new(0.1, 0.1, 0.1)
    part.Position = startPos

    local a0 = Instance.new("Attachment", part)
    local a1 = Instance.new("Attachment", part)
    a1.WorldPosition = endPos

    local beam = Instance.new("Beam", part)
    beam.Attachment0 = a0
    beam.Attachment1 = a1
    beam.Texture = "rbxassetid://6060542021"
    beam.Width0 = 0.08
    beam.Width1 = 0.08
    beam.LightEmission = 1
    beam.FaceCamera = true
    beam.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
    beam.Transparency = NumberSequence.new(0.3)

    task.delay(TracerDuration, function()
        part:Destroy()
    end)
end

local function isVisible(targetPart)
    local camera = workspace.CurrentCamera
    local origin = camera.CFrame.Position
    local direction = targetPart.Position - origin
    
    local raycastParams = RaycastParams.new()
    raycastParams.FilterDescendantsInstances = {LocalPlayer.Character, workspace.CurrentCamera}
    raycastParams.FilterType = Enum.RaycastFilterType.Exclude
    
    local raycastResult = workspace:Raycast(origin, direction, raycastParams)
    
    if raycastResult then
        return raycastResult.Instance:IsDescendantOf(targetPart.Parent)
    end
    return true
end

local WallCheckEnabled = false

local function getBestTarget()
    local target = nil
    local dist = math.huge
    local myChar = LocalPlayer.Character
    if not myChar or not myChar.PrimaryPart then return nil end
    local camera = workspace.CurrentCamera
    
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LocalPlayer and plr.Character then
            local skip = false
            if TeamCheck then
                local sameTeam = false
                pcall(function() if LocalPlayer.Team and plr.Team and LocalPlayer.Team == plr.Team then sameTeam = true end end)
                if not sameTeam then
                    pcall(function() if LocalPlayer:GetAttribute("Team") and plr:GetAttribute("Team") and LocalPlayer:GetAttribute("Team") == plr:GetAttribute("Team") then sameTeam = true end end)
                end
                if sameTeam then skip = true end
            end
            if skip then continue end

            local hum = plr.Character:FindFirstChildOfClass("Humanoid")
            local part = plr.Character:FindFirstChild(TargetPart)
            
            if hum and hum.Health > 0 and part then
                if WallCheckEnabled and not isVisible(part) then continue end
                
                local screenPos, onScreen = camera:WorldToViewportPoint(part.Position)
                local mag = (Vector2.new(screenPos.X, screenPos.Y) - Vector2.new(camera.ViewportSize.X/2, camera.ViewportSize.Y/2)).Magnitude
                
                if onScreen and (not FOV_Enabled or mag <= FOV_Radius) then
                    local d = (part.Position - myChar.PrimaryPart.Position).Magnitude
                    if d < dist then
                        dist = d
                        target = {Char = plr.Character, Part = part}
                    end
                end
            end
        end
    end
    return target
end

local function getActiveWeapon()
    local char = LocalPlayer.Character
    if char then
        local weapon = char:FindFirstChildOfClass("Tool")
        if weapon then return weapon end
    end
    local wepFolder = RS:FindFirstChild("Weapons")
    return wepFolder and wepFolder:FindFirstChild(SelectedWeapon.WeaponName)
end

local function fireRage()
    local targetData = getBestTarget()
    local weapon = getActiveWeapon()
    if not targetData or not weapon or not DamageRemote then return end

    local myChar = LocalPlayer.Character
    local gunPos = myChar and myChar:FindFirstChild("Right Arm") and myChar["Right Arm"].Position or (myChar and myChar.PrimaryPart and myChar.PrimaryPart.Position or Vector3.zero)
    CreateTracer(gunPos, targetData.Part.Position)

    local hitInfo = {
        ["Normal"] = SelectedWeapon.Normal,
        ["Hit"] = targetData.Char,
        ["PartName"] = TargetPart,
        ["hS"] = SelectedWeapon.hS,
        ["Position"] = targetData.Part.Position
    }
    if SelectedWeapon.Noscope then
        hitInfo["Noscope"] = true
    end

    local args = {
        [1] = hitInfo,
        [2] = weapon,
        [3] = SelectedWeapon.Arg3,
        [4] = SelectedWeapon.Arg4
    }

    DamageRemote:FireServer(unpack(args))
end

local AimbotEnabled = false
local AimSensitivity = 0.1

RunService.RenderStepped:Connect(function()
    if AimbotEnabled then
        local targetData = getBestTarget()
        if targetData and targetData.Part then
            local camera = workspace.CurrentCamera
            local targetPos = targetData.Part.Position
            
            local lookAt = CFrame.lookAt(camera.CFrame.Position, targetPos)
            
            camera.CFrame = camera.CFrame:Lerp(lookAt, AimSensitivity)
        end
    end
end)

local Sections = {
    Main = Window:Section({Title = "Ragebot", Opened = true})
}

local Tabs = {
    Ragebot = Sections.Main:Tab({Title = "武器Ragebot", Icon = "crosshair"})
}

Tabs.Ragebot:Dropdown({
    Title = "武器选择",
    Values = WeaponNames,
    Value = WeaponNames[1],
    Callback = function(value)
        for _, config in ipairs(WeaponConfigs) do
            if config.Name == value then
                SelectedWeapon = config
                break
            end
        end
    end
})

Tabs.Ragebot:Toggle({
    Title = "队伍检测",
    Value = false,
    Callback = function(value)
        TeamCheck = value
        updateESP()
    end
})

Tabs.Ragebot:Toggle({
    Title = "子弹轨迹",
    Value = true,
    Callback = function(value)
        TracerEnabled = value
    end
})

Tabs.Ragebot:Slider({
    Title = "轨迹持续时间",
    Value = {Min = 0.05, Max = 1, Default = 0.2},
    Callback = function(value)
        TracerDuration = value
    end
})

Tabs.Ragebot:Input({
    Title = "目标部位",
    Value = "Head",
    Callback = function(value)
        if value ~= "" then
            TargetPart = value
        end
    end
})

Tabs.Ragebot:Toggle({
    Title = "Ragebot",
    Value = false,
    Callback = function(value)
        Running = value
        if Running then
            task.spawn(function()
                while Running do
                    pcall(fireRage)
                    task.wait()
                end
            end)
        end
    end
})

Tabs.Ragebot:Toggle({
    Title = "墙壁检测",
    Value = false,
    Callback = function(value)
        WallCheckEnabled = value
    end
})

Tabs.Ragebot:Toggle({
    Title = "自瞄",
    Value = false,
    Callback = function(value)
        AimbotEnabled = value
    end
})

Tabs.Ragebot:Slider({
    Title = "平滑度",
    Value = {Min = 0.01, Max = 1, Default = 0.1},
    Callback = function(value)
        AimSensitivity = value
    end
})

Tabs.Ragebot:Toggle({
    Title = "显示FOV",
    Value = false,
    Callback = function(value)
        FOV_Enabled = value
        FOV_Circle.Visible = value
    end
})

Tabs.Ragebot:Slider({
    Title = "FOV半径",
    Value = {Min = 50, Max = 500, Default = 150},
    Callback = function(value)
        FOV_Radius = value
        FOV_Circle.Radius = value
    end
})

RunService.RenderStepped:Connect(function()
    if FOV_Enabled then
        FOV_Circle.Position = Vector2.new(workspace.CurrentCamera.ViewportSize.X/2, workspace.CurrentCamera.ViewportSize.Y/2)
    end
end)

local ESP_Section = Window:Section({Title = "ESP", Opened = true})
local ESP_Tab = ESP_Section:Tab({Title = "ESP", Icon = "eye"})

ESP_Tab:Toggle({
    Title = "ESP",
    Value = false,
    Callback = function(value)
        updateESP(value)
    end
})

Players.PlayerAdded:Connect(function(plr)
    plr.CharacterAdded:Connect(function() task.wait(1); updateESP() end)
end)

task.spawn(function()
    while true do
        task.wait(2)
        if ESP_Enabled then updateESP() end
    end
end)