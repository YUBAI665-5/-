local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

local Players = game:GetService("Players")
local Player = Players.LocalPlayer
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

getgenv().QW = getgenv().QW or {
    Speed = 50,
    SpeedEnabled = false,
    FlyEnabled = false,
    NoclipEnabled = false,
    AdminPanelEnabled = false,
    SuckSharkEnabled = false,
    SuckAllEnabled = false,
    SharkESPEnabled = false,
    SpeedThread = nil,
    FlyThread = nil,
    NoclipThread = nil,
    SuckSharkThread = nil,
    SuckAllThread = nil,
    ESPThread = nil,
    ESPObjects = {},
}

local function getCharacter()
    local success, result = pcall(function() return Player.Character end)
    return success and result or nil
end

local function getHumanoid()
    local success, result = pcall(function()
        local char = getCharacter()
        return char and char:FindFirstChildOfClass("Humanoid")
    end)
    return success and result or nil
end

local function getRootPart()
    local success, result = pcall(function()
        local char = getCharacter()
        return char and char:FindFirstChild("HumanoidRootPart")
    end)
    return success and result or nil
end

local function getSharkObjects()
    local sharks = {}
    pcall(function()
        local sharkFolder = Workspace:FindFirstChild("Sharks")
        if sharkFolder then
            for _, child in ipairs(sharkFolder:GetChildren()) do
                if child:IsA("Model") or child:IsA("Part") or child:IsA("MeshPart") then
                    table.insert(sharks, child)
                end
            end
        end
    end)
    return sharks
end

local function getSharkPlayers()
    local sharks = {}
    pcall(function()
        for _, player in ipairs(Players:GetPlayers()) do
            if player ~= Player then
                local team = player.Team
                if team and tostring(team):lower():find("shark") then
                    table.insert(sharks, player)
                end
            end
        end
    end)
    return sharks
end

local function getAllPlayers()
    local allPlayers = {}
    pcall(function()
        local sharkPlayers = {}
        for _, player in ipairs(Players:GetPlayers()) do
            local team = player.Team
            if team and tostring(team):lower():find("shark") then
                sharkPlayers[player] = true
            end
        end
        
        for _, player in ipairs(Players:GetPlayers()) do
            if player ~= Player and not sharkPlayers[player] then
                table.insert(allPlayers, player)
            end
        end
    end)
    return allPlayers
end

local function clearESP()
    for obj, instances in pairs(getgenv().QW.ESPObjects) do
        pcall(function()
            for _, inst in ipairs(instances) do
                if inst and inst.Parent then inst:Destroy() end
            end
        end)
    end
    getgenv().QW.ESPObjects = {}
end

local function createESP(obj, text)
    if not obj or getgenv().QW.ESPObjects[obj] then return end
    
    local hrp = obj:FindFirstChild("HumanoidRootPart") or obj:FindFirstChildWhichIsA("BasePart")
    if not hrp then return end
    
    local highlight = Instance.new("Highlight")
    highlight.Name = "QW_SharkESP"
    highlight.Adornee = obj
    highlight.FillColor = Color3.fromRGB(255, 0, 0)
    highlight.OutlineColor = Color3.fromRGB(255, 0, 0)
    highlight.FillTransparency = 0.3
    highlight.OutlineTransparency = 0
    highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    highlight.Parent = obj

    local bill = Instance.new("BillboardGui")
    bill.Name = "QW_SharkESP_Text"
    bill.Adornee = hrp
    bill.Size = UDim2.new(0, 100, 0, 30)
    bill.StudsOffset = Vector3.new(0, 3, 0)
    bill.AlwaysOnTop = true
    bill.Parent = obj

    local label = Instance.new("TextLabel")
    label.Size = UDim2.new(1, 0, 1, 0)
    label.BackgroundTransparency = 1
    label.Text = text
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.TextStrokeTransparency = 0
    label.TextSize = 14
    label.Parent = bill

    getgenv().QW.ESPObjects[obj] = {highlight, bill}
end

local function espLoop()
    pcall(function()
        for obj in pairs(getgenv().QW.ESPObjects) do
            if not obj or not obj.Parent then
                getgenv().QW.ESPObjects[obj] = nil
            end
        end
        
        local sharkPlayers = getSharkPlayers()
        for _, player in ipairs(sharkPlayers) do
            if player.Character then
                createESP(player.Character, "🦈 " .. player.Name)
            end
        end
        
        local sharkObjects = getSharkObjects()
        for _, shark in ipairs(sharkObjects) do
            createESP(shark, "🦈 鲨鱼")
        end
    end)
end

local function stopSpeed()
    pcall(function()
        local char = getCharacter()
        if char then
            local hum = getHumanoid()
            if hum then hum.WalkSpeed = 16 end
        end
    end)
end

local function speedLoop()
    pcall(function()
        local hum = getHumanoid()
        if hum then hum.WalkSpeed = getgenv().QW.Speed end
    end)
end

local function stopFly()
    pcall(function()
        local char = getCharacter()
        if char then
            local hum = getHumanoid()
            if hum then hum.PlatformStand = false end
            local root = getRootPart()
            if root then
                local bodyVel = root:FindFirstChild("QW_FlyVelocity")
                if bodyVel then bodyVel:Destroy() end
                local bodyGyro = root:FindFirstChild("QW_BodyGyro")
                if bodyGyro then bodyGyro:Destroy() end
            end
        end
    end)
end

local function flyLoop()
    pcall(function()
        local char = getCharacter()
        if not char then return end
        local hum = getHumanoid()
        local root = getRootPart()
        if not hum or not root then return end
        
        hum.PlatformStand = true
        hum.WalkSpeed = getgenv().QW.Speed
        
        local cam = Workspace.CurrentCamera
        if not cam then return end
        
        local moveDir = hum.MoveDirection
        if moveDir and moveDir.Magnitude > 0 then
            local bodyVel = root:FindFirstChild("QW_FlyVelocity")
            if not bodyVel then
                bodyVel = Instance.new("BodyVelocity")
                bodyVel.Name = "QW_FlyVelocity"
                bodyVel.MaxForce = Vector3.new(4000, 4000, 4000)
                bodyVel.Parent = root
            end
            bodyVel.Velocity = cam.CFrame.LookVector * moveDir.Z * getgenv().QW.Speed +
                               cam.CFrame.RightVector * moveDir.X * getgenv().QW.Speed +
                               Vector3.new(0, moveDir.Y * getgenv().QW.Speed, 0)
        end
        
        local bodyGyro = root:FindFirstChild("QW_BodyGyro")
        if not bodyGyro then
            bodyGyro = Instance.new("BodyGyro")
            bodyGyro.Name = "QW_BodyGyro"
            bodyGyro.MaxTorque = Vector3.new(4000, 4000, 4000)
            bodyGyro.P = 1000
            bodyGyro.Parent = root
        end
        bodyGyro.CFrame = cam.CFrame
    end)
end

local function noclipLoop()
    pcall(function()
        local char = getCharacter()
        if char then
            for _, part in ipairs(char:GetChildren()) do
                if part:IsA("BasePart") then part.CanCollide = false end
            end
        end
    end)
end

local function suckSharkLoop()
    pcall(function()
        local hrp = getRootPart()
        if not hrp then return end
        
        local sharks = getSharkObjects()
        for _, shark in ipairs(sharks) do
            local primaryPart = shark.PrimaryPart or shark:FindFirstChildWhichIsA("BasePart")
            if primaryPart then
                if shark:IsA("Model") then
                    shark:SetPrimaryPartCFrame(hrp.CFrame * CFrame.new(0, 15, -20))
                else
                    shark.CFrame = hrp.CFrame * CFrame.new(0, 15, -20)
                end
            end
        end
    end)
end

local function suckAllLoop()
    pcall(function()
        local hrp = getRootPart()
        if not hrp then return end
        
        local players = getAllPlayers()
        for _, player in ipairs(players) do
            if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
                local playerHRP = player.Character.HumanoidRootPart
                playerHRP.CFrame = hrp.CFrame * CFrame.new(0, 15, -20)
            end
        end
    end)
end

local function getSharkBlaster()
    pcall(function()
        local sharkBlaster = ReplicatedStorage:FindFirstChild("ClientViewportObjects")
        if sharkBlaster then
            sharkBlaster = sharkBlaster:FindFirstChild("Weapons")
            if sharkBlaster then
                sharkBlaster = sharkBlaster:FindFirstChild("SharkBlaster")
                if sharkBlaster then
                    local backpack = Player:FindFirstChild("Backpack")
                    if backpack and not backpack:FindFirstChild("SharkBlaster") then
                        sharkBlaster:Clone().Parent = backpack
                        WindUI:Notify({ Title = "获取成功", Content = "鲨鱼冲击波已添加到背包", Duration = 2 })
                    else
                        WindUI:Notify({ Title = "提示", Content = "背包中已有鲨鱼冲击波", Duration = 2 })
                    end
                else
                    WindUI:Notify({ Title = "获取失败", Content = "未找到鲨鱼冲击波", Duration = 2 })
                end
            end
        end
    end)
end


WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)

local BaseTab = Window:Tab({ Title = "基础", Icon = "settings" })
Window:SelectTab(1)
BaseTab:Toggle({
    Title = "加速",
    Value = getgenv().QW.SpeedEnabled,
    Callback = function(state)
        getgenv().QW.SpeedEnabled = state
        if state then
            if getgenv().QW.SpeedThread then task.cancel(getgenv().QW.SpeedThread) end
            getgenv().QW.SpeedThread = task.spawn(function()
                while getgenv().QW.SpeedEnabled do
                    speedLoop()
                    task.wait(0.1)
                end
            end)
            WindUI:Notify({ Title = "加速", Content = "已开启", Duration = 1.5 })
        else
            if getgenv().QW.SpeedThread then
                task.cancel(getgenv().QW.SpeedThread)
                getgenv().QW.SpeedThread = nil
            end
            stopSpeed()
            WindUI:Notify({ Title = "加速", Content = "已关闭", Duration = 1.5 })
        end
    end
})

BaseTab:Toggle({
    Title = "飞行",
    Value = getgenv().QW.FlyEnabled,
    Callback = function(state)
        getgenv().QW.FlyEnabled = state
        if state then
            if getgenv().QW.FlyThread then task.cancel(getgenv().QW.FlyThread) end
            getgenv().QW.FlyThread = task.spawn(function()
                while getgenv().QW.FlyEnabled do
                    flyLoop()
                    task.wait(0.1)
                end
            end)
            WindUI:Notify({ Title = "飞行", Content = "已开启", Duration = 1.5 })
        else
            if getgenv().QW.FlyThread then
                task.cancel(getgenv().QW.FlyThread)
                getgenv().QW.FlyThread = nil
            end
            stopFly()
            WindUI:Notify({ Title = "飞行", Content = "已关闭", Duration = 1.5 })
        end
    end
})

BaseTab:Slider({
    Title = "速度",
    Value = { Min = 10, Max = 200, Default = getgenv().QW.Speed },
    Callback = function(value)
        getgenv().QW.Speed = value
    end
})

BaseTab:Divider()

BaseTab:Toggle({
    Title = "穿墙",
    Value = getgenv().QW.NoclipEnabled,
    Callback = function(state)
        getgenv().QW.NoclipEnabled = state
        if state then
            if getgenv().QW.NoclipThread then task.cancel(getgenv().QW.NoclipThread) end
            getgenv().QW.NoclipThread = task.spawn(function()
                while getgenv().QW.NoclipEnabled do
                    noclipLoop()
                    task.wait(0.2)
                end
            end)
            WindUI:Notify({ Title = "穿墙", Content = "已开启", Duration = 1.5 })
        else
            if getgenv().QW.NoclipThread then
                task.cancel(getgenv().QW.NoclipThread)
                getgenv().QW.NoclipThread = nil
            end
            WindUI:Notify({ Title = "穿墙", Content = "已关闭", Duration = 1.5 })
        end
    end
})

local ESPTab = Window:Tab({ Title = "ESP", Icon = "eye" })

ESPTab:Toggle({
    Title = "鲨鱼ESP",
    Value = getgenv().QW.SharkESPEnabled,
    Callback = function(state)
        getgenv().QW.SharkESPEnabled = state
        if state then
            if getgenv().QW.ESPThread then task.cancel(getgenv().QW.ESPThread) end
            getgenv().QW.ESPThread = task.spawn(function()
                while getgenv().QW.SharkESPEnabled do
                    espLoop()
                    task.wait(0.5)
                end
            end)
            WindUI:Notify({ Title = "鲨鱼ESP", Content = "已开启", Duration = 1.5 })
        else
            if getgenv().QW.ESPThread then
                task.cancel(getgenv().QW.ESPThread)
                getgenv().QW.ESPThread = nil
            end
            clearESP()
            WindUI:Notify({ Title = "鲨鱼ESP", Content = "已关闭", Duration = 1.5 })
        end
    end
})

local FeatureTab = Window:Tab({ Title = "特色", Icon = "star" })

FeatureTab:Toggle({
    Title = "管理员面板",
    Value = getgenv().QW.AdminPanelEnabled,
    Callback = function(state)
        getgenv().QW.AdminPanelEnabled = state
        pcall(function()
            local panel = Player.PlayerGui:FindFirstChild("AdminPanel")
            if panel then
                panel.Enabled = state
            end
        end)
        WindUI:Notify({ Title = "管理员面板", Content = state and "已开启" or "已关闭", Duration = 1.5 })
    end
})

FeatureTab:Divider()

FeatureTab:Toggle({
    Title = "循环吸鲨鱼",
    Value = getgenv().QW.SuckSharkEnabled,
    Callback = function(state)
        getgenv().QW.SuckSharkEnabled = state
        if state then
            if getgenv().QW.SuckSharkThread then task.cancel(getgenv().QW.SuckSharkThread) end
            getgenv().QW.SuckSharkThread = task.spawn(function()
                while getgenv().QW.SuckSharkEnabled do
                    suckSharkLoop()
                    task.wait(0.1)
                end
            end)
            WindUI:Notify({ Title = "循环吸鲨鱼", Content = "已开启", Duration = 1.5 })
        else
            if getgenv().QW.SuckSharkThread then
                task.cancel(getgenv().QW.SuckSharkThread)
                getgenv().QW.SuckSharkThread = nil
            end
            WindUI:Notify({ Title = "循环吸鲨鱼", Content = "已关闭", Duration = 1.5 })
        end
    end
})

FeatureTab:Toggle({
    Title = "吸全部玩家",
    Value = getgenv().QW.SuckAllEnabled,
    Callback = function(state)
        getgenv().QW.SuckAllEnabled = state
        if state then
            if getgenv().QW.SuckAllThread then task.cancel(getgenv().QW.SuckAllThread) end
            getgenv().QW.SuckAllThread = task.spawn(function()
                while getgenv().QW.SuckAllEnabled do
                    suckAllLoop()
                    task.wait(0.1)
                end
            end)
            WindUI:Notify({ Title = "吸全部玩家", Content = "已开启", Duration = 1.5 })
        else
            if getgenv().QW.SuckAllThread then
                task.cancel(getgenv().QW.SuckAllThread)
                getgenv().QW.SuckAllThread = nil
            end
            WindUI:Notify({ Title = "吸全部玩家", Content = "已关闭", Duration = 1.5 })
        end
    end
})

FeatureTab:Divider()

FeatureTab:Button({
    Title = "获取鲨鱼冲击波",
    Callback = function()
        getSharkBlaster()
    end
})