local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)

local lp = game.Players.LocalPlayer
local RunService = game:GetService("RunService")
local rs = game:GetService("ReplicatedStorage")

local speedEnabled = false
local currentSpeed = 16
local noclipEnabled = false
local noclipCoroutine = nil
local killActive = false
local killCoroutine = nil
local autoBuyHealthEnabled = false
local autoBuyHealthCoroutine = nil
local autoUpgradeWeaponEnabled = false
local autoUpgradeWeaponCoroutine = nil
local autoSkipRoundEnabled = false
local autoSkipRoundCoroutine = nil
local autoPickupCrystalEnabled = false
local autoPickupCoroutine = nil
local lastHealthPurchaseTime = 0
local upgradeSent = { false, false, false }
local upgradeLevels = { 150, 750, 2500 }

local purchaseHealthRemote, purchaseWeaponRemote, gunHitRemote, skipVoteRemote
pcall(function()
    local upgradeRemotes = rs:WaitForChild("UpgradeRemotes")
    purchaseHealthRemote = upgradeRemotes:WaitForChild("PurchaseHealthUpgrade")
    purchaseWeaponRemote = upgradeRemotes:WaitForChild("PurchaseWeaponUpgrade")
    gunHitRemote = rs:WaitForChild("GunRemotes"):WaitForChild("GunHit")
    skipVoteRemote = rs:WaitForChild("WaveRemotes"):WaitForChild("SkipVote")
end)

local function getZombiesDetailed()
    local zombies = {}
    local folder = workspace:FindFirstChild("Zombies_Local")
    if not folder then return zombies end
    for _, child in ipairs(folder:GetChildren()) do
        if child:IsA("Model") and string.find(child.Name, "Zombie") then
            local rootPart = child:FindFirstChild("HumanoidRootPart") or child:FindFirstChild("Head") or child.PrimaryPart
            if rootPart then
                local idStr = string.match(child.Name, "(%d+)$")
                table.insert(zombies, {
                    position = rootPart.Position,
                    id = idStr and tonumber(idStr) or 0
                })
            end
        end
    end
    return zombies
end

local function getWeaponName()
    local folder = workspace:FindFirstChild(lp.Name)
    if folder then
        for _, child in ipairs(folder:GetChildren()) do
            if child:IsA("Model") or child:IsA("Tool") then return child.Name end
        end
    end
    return "Pistol"
end

local function getNearestCrystal(playerPos)
    local voidShards = workspace:FindFirstChild("VoidShards")
    if not voidShards then return nil end
    local nearest, minDist = nil, math.huge
    for _, child in ipairs(voidShards:GetChildren()) do
        local pos = (child:IsA("BasePart") and child.Position) or (child:IsA("Model") and child:GetPivot().Position)
        if pos then
            local dist = (pos - playerPos).Magnitude
            if dist < minDist then
                minDist = dist
                nearest = child
            end
        end
    end
    return nearest
end

local lockYConnection = nil
local function startLockY(targetCF)
    if lockYConnection then lockYConnection:Disconnect() end
    local char = lp.Character
    if not char then return end
    local hum = char:FindFirstChildOfClass("Humanoid")
    if hum then
        hum.PlatformStand = true
        hum.AutoRotate = false
    end
    lockYConnection = RunService.Heartbeat:Connect(function()
        local hrp = char:FindFirstChild("HumanoidRootPart")
        if hrp then hrp.CFrame = targetCF end
        if hum then 
            hum.WalkSpeed = 0 
            hum.JumpPower = 0
        end
    end)
end

local function stopLockY()
    if lockYConnection then lockYConnection:Disconnect(); lockYConnection = nil end
    local char = lp.Character
    if char then
        local hum = char:FindFirstChildOfClass("Humanoid")
        if hum then
            hum.PlatformStand = false
            hum.AutoRotate = true
            hum.WalkSpeed = speedEnabled and currentSpeed or 16
            hum.JumpPower = 50
        end
    end
end

local function killLoopFunc()
    while killActive do
        local char = lp.Character
        local root = char and char:FindFirstChild("HumanoidRootPart")
        if root then
            local zombies = getZombiesDetailed()
            local weapon = getWeaponName()
            for _, z in ipairs(zombies) do
                if not killActive then break end
                pcall(function() gunHitRemote:FireServer(weapon, z.id, z.position) end)
                task.wait(0.02)
            end
        end
        task.wait(0.05)
    end
end

local TabBasic = Window:Tab({ Title = "基础", Icon = "settings" })

TabBasic:Toggle({
    Title = "加速移动",
    Value = false,
    Callback = function(state)
        speedEnabled = state
        local hum = lp.Character and lp.Character:FindFirstChild("Humanoid")
        if hum then hum.WalkSpeed = state and currentSpeed or 16 end
    end
})

TabBasic:Slider({
    Title = "行走速度",
    Step = 1,
    Value = { Min = 16, Max = 150, Default = 50 },
    Callback = function(value)
        currentSpeed = value
        local hum = lp.Character and lp.Character:FindFirstChild("Humanoid")
        if speedEnabled and hum then hum.WalkSpeed = value end
    end
})

TabBasic:Toggle({
    Title = "穿墙模式",
    Value = false,
    Callback = function(state)
        noclipEnabled = state
        if noclipCoroutine then task.cancel(noclipCoroutine) end
        if state then
            noclipCoroutine = task.spawn(function()
                while noclipEnabled do
                    if lp.Character then
                        for _, p in ipairs(lp.Character:GetDescendants()) do
                            if p:IsA("BasePart") then p.CanCollide = false end
                        end
                    end
                    task.wait()
                end
            end)
        else
            if lp.Character then
                for _, p in ipairs(lp.Character:GetDescendants()) do
                    if p:IsA("BasePart") then p.CanCollide = true end
                end
            end
        end
    end
})

local TabFeature = Window:Tab({ Title = "特色", Icon = "zap" })

TabFeature:Toggle({
    Title = "全图杀戮",
    Value = false,
    Callback = function(state)
        killActive = state
        if killCoroutine then task.cancel(killCoroutine) end
        if state then killCoroutine = task.spawn(killLoopFunc) end
    end
})

TabFeature:Toggle({
    Title = "自动购买生命",
    Value = false,
    Callback = function(state)
        autoBuyHealthEnabled = state
        if autoBuyHealthCoroutine then task.cancel(autoBuyHealthCoroutine) end
        if state then
            autoBuyHealthCoroutine = task.spawn(function()
                while autoBuyHealthEnabled do
                    local hum = lp.Character and lp.Character:FindFirstChild("Humanoid")
                    if hum and hum.Health < 30 and tick() - lastHealthPurchaseTime >= 2 then
                        lastHealthPurchaseTime = tick()
                        if purchaseHealthRemote then pcall(function() purchaseHealthRemote:FireServer() end) end
                    end
                    task.wait(0.5)
                end
            end)
        end
    end
})

TabFeature:Toggle({
    Title = "自动升级武器",
    Value = false,
    Callback = function(state)
        autoUpgradeWeaponEnabled = state
        if state then
            upgradeSent = {false, false, false}
            autoUpgradeWeaponCoroutine = task.spawn(function()
                while autoUpgradeWeaponEnabled do
                    local success, text = pcall(function() return lp.PlayerGui.MainGui.ControlPanel2.NextUpgrade.TextLabel.Text end)
                    if success and text then
                        local num = tonumber(text:match("%d+")) or 0
                        for i, threshold in ipairs(upgradeLevels) do
                            if not upgradeSent[i] and num > threshold then
                                if purchaseWeaponRemote then pcall(function() purchaseWeaponRemote:FireServer() end) end
                                upgradeSent[i] = true
                            end
                        end
                    end
                    task.wait(1)
                end
            end)
        elseif autoUpgradeWeaponCoroutine then
            task.cancel(autoUpgradeWeaponCoroutine)
        end
    end
})

local TabAuto = Window:Tab({ Title = "自动", Icon = "cpu" })

TabAuto:Toggle({
    Title = "自动跳过回合",
    Value = false,
    Callback = function(state)
        autoSkipRoundEnabled = state
        if autoSkipRoundCoroutine then task.cancel(autoSkipRoundCoroutine) end
        if state then
            autoSkipRoundCoroutine = task.spawn(function()
                while autoSkipRoundEnabled do
                    if skipVoteRemote then pcall(function() skipVoteRemote:FireServer(true) end) end
                    task.wait(5)
                end
            end)
        end
    end
})

TabAuto:Toggle({
    Title = "自动拾取水晶",
    Value = false,
    Callback = function(state)
        autoPickupCrystalEnabled = state
        if autoPickupCoroutine then task.cancel(autoPickupCoroutine) end
        if state then
            autoPickupCoroutine = task.spawn(function()
                while autoPickupCrystalEnabled do
                    task.wait(1)
                    local hrp = lp.Character and lp.Character:FindFirstChild("HumanoidRootPart")
                    if hrp then
                        local nearest = getNearestCrystal(hrp.Position)
                        if nearest then
                            local pos = nearest:IsA("BasePart") and nearest.Position or nearest:GetPivot().Position
                            local oldCF = hrp.CFrame
                            hrp.CFrame = CFrame.new(pos) + Vector3.new(0, 3, 0)
                            task.wait(0.3)
                            hrp.CFrame = oldCF
                            task.wait(2)
                        end
                    end
                end
            end)
        end
    end
})

local TabFun = Window:Tab({ Title = "娱乐", Icon = "gamepad" })

TabFun:Button({
    Title = "自动秒杀全图怪物",
    Callback = function()
        local galacticRifle = workspace:FindFirstChild("Galactic Rifle (vers 1)")
        local hrp = lp.Character and lp.Character:FindFirstChild("HumanoidRootPart")
        if galacticRifle and hrp then
            local targetPos = galacticRifle:IsA("BasePart") and galacticRifle.Position or galacticRifle:GetPivot().Position
            local targetCF = CFrame.new(targetPos) + Vector3.new(0, 3, 0)
            
            startLockY(targetCF)
            WindUI:Notify({ Title = "秒杀启动", Content = "已锁定位置，等待18秒清除怪物...", Duration = 5 })
            
            task.delay(18, function()
                stopLockY()
                WindUI:Notify({ Title = "秒杀完成", Content = "锁定已解除", Duration = 3 })
            end)
        else
            WindUI:Notify({ Title = "错误", Content = "未找到 Galactic Rifle 或角色未加载", Duration = 3 })
        end
    end
})

lp.CharacterAdded:Connect(function(char)
    task.wait(1)
    local hum = char:WaitForChild("Humanoid")
    if speedEnabled then hum.WalkSpeed = currentSpeed end
end)