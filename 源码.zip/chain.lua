local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)

local Tab1 = Window:Tab({
    Title = "功能",
    Icon = "house",
    Locked = false,
})
Window:SelectTab(1)
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local RunService = game:GetService("RunService")

local combatStaminaEnabled = false
local staminaEnabled = false
local combatLoop = nil
local staminaLoop = nil

local function setCombatStamina(value)
    local char = workspace:FindFirstChild(LocalPlayer.Name)
    if char and char:FindFirstChild("Stats") then
        local stat = char.Stats:FindFirstChild("CombatStamina")
        if stat then stat.Value = value end
    end
end

local function setStamina(value)
    local char = workspace:FindFirstChild(LocalPlayer.Name)
    if char and char:FindFirstChild("Stats") then
        local stat = char.Stats:FindFirstChild("Stamina")
        if stat then stat.Value = value end
    end
end

local function startCombatLoop()
    if combatLoop then return end
    combatLoop = RunService.Heartbeat:Connect(function()
        if combatStaminaEnabled then setCombatStamina(100) end
    end)
end

local function startStaminaLoop()
    if staminaLoop then return end
    staminaLoop = RunService.Heartbeat:Connect(function()
        if staminaEnabled then setStamina(100) end
    end)
end

local function stopCombatLoop()
    if combatLoop then combatLoop:Disconnect() combatLoop = nil end
end

local function stopStaminaLoop()
    if staminaLoop then staminaLoop:Disconnect() staminaLoop = nil end
end

LocalPlayer.CharacterAdded:Connect(function()
    task.wait(1)
    if combatStaminaEnabled then setCombatStamina(100) end
    if staminaEnabled then setStamina(100) end
end)

Tab1:Toggle({
    Title = "无限战斗体力",
    Value = false,
    Callback = function(state)
        combatStaminaEnabled = state
        if state then startCombatLoop() else stopCombatLoop() end
    end
})

Tab1:Toggle({
    Title = "无限体力",
    Value = false,
    Callback = function(state)
        staminaEnabled = state
        if state then startStaminaLoop() else stopStaminaLoop() end
    end
})

local chainESPEnabled = false
local chainESPConnection = nil
local currentChain = nil

local function createChainESP(chain)
    if not chain:FindFirstChild("Highlight") then
        local h = Instance.new("Highlight")
        h.Name = "Highlight"; h.Adornee = chain; h.FillColor = Color3.fromRGB(255, 0, 0); h.FillTransparency = 0.8
        h.OutlineColor = Color3.fromRGB(255, 60, 60); h.OutlineTransparency = 0; h.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
        h.Parent = chain
    end
    if not chain:FindFirstChild("NameGui") then
        local gui = Instance.new("BillboardGui")
        gui.Name = "NameGui"; gui.Size = UDim2.new(0, 150, 0, 30); gui.StudsOffset = Vector3.new(0, 5, 0)
        gui.Adornee = chain; gui.AlwaysOnTop = true; gui.LightInfluence = 0; gui.Parent = chain
        local titleLabel = Instance.new("TextLabel")
        titleLabel.Name = "TitleLabel"; titleLabel.Size = UDim2.new(1, 0, 0.5, 0); titleLabel.Text = "CHAIN"
        titleLabel.TextColor3 = Color3.new(1, 0, 0); titleLabel.TextScaled = true; titleLabel.Font = Enum.Font.GothamBold
        titleLabel.BackgroundTransparency = 1; titleLabel.Parent = gui
        local attrLabel = Instance.new("TextLabel")
        attrLabel.Name = "AttrLabel"; attrLabel.Size = UDim2.new(1, 0, 0.5, 0); attrLabel.Position = UDim2.new(0, 0, 0.5, 0)
        attrLabel.RichText = true; attrLabel.Text = ""; attrLabel.TextColor3 = Color3.new(1, 1, 1); attrLabel.TextScaled = true
        attrLabel.Font = Enum.Font.Gotham; attrLabel.BackgroundTransparency = 1; attrLabel.Parent = gui
    end
end

local function updateChainAttributes(chain)
    local gui = chain:FindFirstChild("NameGui")
    if gui then
        local attrLabel = gui:FindFirstChild("AttrLabel")
        if attrLabel then
            local anger = chain:GetAttribute("Anger") or 0
            local burst = chain:GetAttribute("Burst") or 0
            local choke = chain:GetAttribute("ChokeMeter") or 0
            attrLabel.Text = string.format('[血月度: <font color="rgb(255,255,255)">%.0f%%</font>] [捶地: <font color="rgb(255,255,255)">%.0f%%</font>] [掐脖: <font color="rgb(255,255,255)">%.0f%%</font>]', anger, burst, choke)
        end
    end
end

local function refreshChainESP()
    local chain = workspace:FindFirstChild("Misc") and workspace.Misc:FindFirstChild("AI") and workspace.Misc.AI:FindFirstChild("CHAIN")
    if chain then
        if currentChain ~= chain then
            if currentChain then local h = currentChain:FindFirstChild("Highlight") if h then h:Destroy() end end
            currentChain = chain; createChainESP(chain)
        end
        updateChainAttributes(chain)
    end
end

Tab1:Toggle({
    Title = "透视chain",
    Value = false,
    Callback = function(state)
        if state then chainESPEnabled = true; chainESPConnection = RunService.Heartbeat:Connect(refreshChainESP)
        else chainESPEnabled = false; if chainESPConnection then chainESPConnection:Disconnect() end end
    end
})

local playerESPEnabled = false
local playerESPConnections = {}
local trackedCharacters = {}

local function addESP(character, player)
    if not character:FindFirstChild("Highlight") then
        local h = Instance.new("Highlight", character)
        h.Name = "Highlight"; h.FillColor = Color3.fromRGB(0, 255, 0); h.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    end
    if not character:FindFirstChild("NameGui") then
        local gui = Instance.new("BillboardGui", character)
        gui.Name = "NameGui"; gui.Size = UDim2.new(0, 50, 0, 10); gui.AlwaysOnTop = true
        local label = Instance.new("TextLabel", gui); label.Size = UDim2.new(1,0,1,0); label.Text = player.Name; label.TextColor3 = Color3.new(0,1,0); label.BackgroundTransparency = 1; label.TextScaled = true
    end
end

Tab1:Toggle({
    Title = "透视玩家",
    Default = false,
    Callback = function(state)
        playerESPEnabled = state
        if state then
            for _, player in ipairs(Players:GetPlayers()) do if player ~= LocalPlayer and player.Character then addESP(player.Character, player) end end
        end
    end
})

local Lighting = game:GetService("Lighting")
local highlightLoop
Tab1:Toggle({
    Title = "高亮",
    Default = false,
    Callback = function(state)
        if state then
            highlightLoop = task.spawn(function()
                while task.wait(0.5) do Lighting.Brightness = 2; Lighting.ClockTime = 13.5; Lighting.GlobalShadows = false end
            end)
        else if highlightLoop then task.cancel(highlightLoop) end end
    end
})

local targetPositions = {
    Vector3.new(-26.879, -107.017, -204.777), Vector3.new(-110.858, -86.338, 211.858),
    Vector3.new(43.304, -97.968, 349.153), Vector3.new(164.498, -103.651, -35.760),
    Vector3.new(308.971, -113.493, -250.460), Vector3.new(-203.818, -110.890, -108.904),
    Vector3.new(-381.873, -115.021, 42.071),
}
Tab1:Toggle({
    Title = "传送捡废铁",
    Value = false,
    Callback = function(state)
        _G.ScrapRunning = state
        if state then task.spawn(function()
            while _G.ScrapRunning do
                for _, pos in ipairs(targetPositions) do
                    if not _G.ScrapRunning then break end
                    LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(pos + Vector3.new(0,3,0))
                    task.wait(3)
                end
            end
        end) end
    end
})

Tab1:Toggle({
    Title = "传送捡魔法书碎片",
    Value = false,
    Callback = function(state)
        _G.ArtRunning = state
        if state then task.spawn(function()
            while _G.ArtRunning do
                local arts = workspace.Misc.Zones.LootingItems.Artifacts:GetChildren()
                for _, m in pairs(arts) do
                    for _, p in pairs(m:GetChildren()) do
                        if p:IsA("MeshPart") and p.Transparency == 0 then
                            LocalPlayer.Character.HumanoidRootPart.CFrame = p.CFrame
                            task.wait(0.3); fireproximityprompt(p:FindFirstChildOfClass("ProximityPrompt"))
                            task.wait(0.5)
                        end
                    end
                end
                task.wait(1)
            end
        end) end
    end
})

Tab1:Toggle({ Title = "显示聊天框", Callback = function(state) game:GetService("TextChatService").ChatWindowConfiguration.Enabled = state end })
Tab1:Toggle({ Title = "强制第三人称", Callback = function(state) LocalPlayer.CameraMaxZoomDistance = state and 99999 or 16; LocalPlayer.CameraMode = state and Enum.CameraMode.Classic or Enum.CameraMode.LockFirstPerson end })
Tab1:Button({ Title = "删除雾", Callback = function() if Lighting:FindFirstChild("Rainy") then Lighting.Rainy:Destroy() end end })

local Tab2 = Window:Tab({
    Title = "暴力功能",
    Icon = "hand",
    Locked = false,
})

Tab2:Paragraph({ Title = "注意事项", Desc = "不看的人死妈，要先点反作弊，然后开启无限闪避之后再点一下闪避键自动无限闪避就有用了...", Color = "Red" })

Tab2:Button({ Title = "绕过反作弊", Callback = function() loadstring(game:HttpGet("https://raw.githubusercontent.com/Pixeluted/adoniscries/main/Source.lua", true))() end })

local function smoothLookAt(currentCFrame, targetPos, speed)
    local direction = (targetPos - currentCFrame.Position).Unit
    local lerpedLook = currentCFrame.LookVector:Lerp(direction, speed)
    return CFrame.new(currentCFrame.Position, currentCFrame.Position + lerpedLook)
end
Tab2:Toggle({
    Title = "自瞄chain",
    Callback = function(state)
        if state then _G.AimLoop = RunService.RenderStepped:Connect(function()
            local chain = workspace:FindFirstChild("Misc") and workspace.Misc.AI:FindFirstChild("CHAIN")
            if chain and chain:FindFirstChild("HumanoidRootPart") then
                workspace.CurrentCamera.CFrame = smoothLookAt(workspace.CurrentCamera.CFrame, chain.HumanoidRootPart.Position, 0.3)
            end
        end) else if _G.AimLoop then _G.AimLoop:Disconnect() end end
    end
})

Tab2:Toggle({ Title = "chain爆炸自动躲v1", Callback = function(state) _G.DodgeV1 = state end })
Tab2:Toggle({ Title = "chain爆炸自动躲v2", Callback = function(state) _G.DodgeV2 = state end })

local mt = getrawmetatable(game); local old = mt.__namecall; setreadonly(mt, false)
local lastCTS, lastInteract
mt.__namecall = function(self, ...)
    local method = getnamecallmethod(); local args = {...}
    if method == "FireServer" then
        if self.Name == "CTS" then lastCTS = args end
        if self.Name == "Interact" then lastInteract = args end
    end
    return old(self, ...)
end
setreadonly(mt, true)

Tab2:Toggle({
    Title = "自动无限闪避",
    Callback = function(state)
        _G.InfDodge = state
        if state then task.spawn(function()
            while _G.InfDodge do
                local remote = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("CharacterMobility") and LocalPlayer.Character.CharacterMobility:FindFirstChild("CTS")
                if remote and lastCTS then remote:FireServer(unpack(lastCTS)) end
                task.wait(0.3)
            end
        end) end
    end
})

Tab2:Toggle({
    Title = "无敌",
    Callback = function(state)
        _G.GodMode = state
        if state then task.spawn(function()
            while _G.GodMode do
                local remote = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("CharacterHandler") and LocalPlayer.Character.CharacterHandler.Contents.Remotes:FindFirstChild("Interact")
                if remote and lastInteract then remote:FireServer(unpack(lastInteract)) end
                task.wait(1)
            end
        end) end
    end
})

Tab2:Toggle({ Title = "自动拼刀", Callback = function(state) 
    if state then _G.ClashLoop = RunService.Heartbeat:Connect(function() pcall(function() LocalPlayer.Character.Stats.ClashStrength.Value = 100 end) end)
    else if _G.ClashLoop then _G.ClashLoop:Disconnect() end end
end })

local Tab3 = Window:Tab({ Title = "蓝图解锁", Icon = "file-check" })
local function UnlockAttr(attr) LocalPlayer:WaitForChild("PlayerStats"):WaitForChild("Blueprints"):SetAttribute(attr, true) end

Tab3:Button({ Title = "解锁小刀", Callback = function() UnlockAttr("CombatKnife") end })
Tab3:Button({ Title = "解锁喷子", Callback = function() UnlockAttr("DoubleBarrel") end })
Tab3:Button({ Title = "解锁m1911", Callback = function() UnlockAttr("M1911") end })
Tab3:Button({ Title = "解锁马切特", Callback = function() UnlockAttr("Machete") end })
Tab3:Button({ Title = "解锁魔法书", Callback = function() UnlockAttr("SpellBook") end })
Tab3:Button({ Title = "解锁神器任务", Callback = function() LocalPlayer.PlayerStats.Quests:SetAttribute("ArtifactQuest", true) end })

local Tab4 = Window:Tab({ Title = "传送", Icon = "zap" })
local function Teleport(pos) LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(pos + Vector3.new(0,3,0)) end

Tab4:Button({ Title = "chain出生地", Callback = function() Teleport(Vector3.new(-26.879, -107.017, -204.777)) end })
Tab4:Button({ Title = "商店", Callback = function() Teleport(Vector3.new(-110.858, -86.338, 211.858)) end })
Tab4:Button({ Title = "排行榜", Callback = function() Teleport(Vector3.new(43.304, -97.968, 349.153)) end })
Tab4:Button({ Title = "工作间", Callback = function() Teleport(Vector3.new(164.498, -103.651, -35.760)) end })
Tab4:Button({ Title = "仓库", Callback = function() Teleport(Vector3.new(308.971, -113.493, -250.460)) end })
Tab4:Button({ Title = "发电站", Callback = function() Teleport(Vector3.new(-203.818, -110.890, -108.904)) end })
Tab4:Button({ Title = "收音机站", Callback = function() Teleport(Vector3.new(-381.873, -115.021, 42.071)) end })

local Tab5 = Window:Tab({ Title = "商店", Icon = "store" })
Tab5:Button({ Title = "打开商店界面", Callback = function() LocalPlayer.PlayerGui.Ingame.Shop.Visible = true end })
