local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)

local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")
local LocalPlayer = Players.LocalPlayer
local Camera = Workspace.CurrentCamera

local valWalkSpeed = 15
local modifyWalkSpeed = false
local noclipConn = nil
local hitBoxExpander = false
local valHitBox = 15
local activeInstantPrompt = false
local activeBigPrompt = false
local safeLastPos = nil
local antiDeath = { conn = nil, lastPos = nil, teleported = false, debounce = false }
local healthThreshold = 30
local viewKiller = false
local killerAddedConn, killerRemovedConn
local tpKillMode = "最近玩家"
local tpKillTarget = ""
local tpKillConn = nil
local oldLighting = {}
local espData = { survivors = {}, killers = {}, generators = {}, fuseboxes = {}, doors = {} }
local CanParry = true
local genConn = nil
local dotConn = nil
local autoEscapeConn = nil

local safePart = Workspace:FindFirstChild("SafeZone_Linni")
if not safePart then
    safePart = Instance.new("Part")
    safePart.Name = "SafeZone_Linni"; safePart.Size = Vector3.new(50, 2, 50)
    safePart.Position = Vector3.new(0, 1000, 0); safePart.Anchored = true
    safePart.CanCollide = true; safePart.Material = Enum.Material.ForceField; safePart.Parent = Workspace
end

local Tabs = {
    Local = Window:Tab({ Title = "玩家移动", Icon = "user" }),
    Visuals = Window:Tab({ Title = "视觉与环境", Icon = "eye" }),
    Survivor = Window:Tab({ Title = "幸存者", Icon = "list" }),
    Combat = Window:Tab({ Title = "杀手辅助", Icon = "swords" }),
    Teleports = Window:Tab({ Title = "地图与传送", Icon = "map" })
}

Window:SelectTab(1)

Tabs.Local:Section({ Title = "属性" })
Tabs.Local:Slider({ Title = "速度(25以内)", Value = { Min = 0, Max = 50, Default = 15 }, Callback = function(v) valWalkSpeed = v end })
Tabs.Local:Toggle({ Title = "启用", Callback = function(v) modifyWalkSpeed = v end })

Tabs.Local:Section({ Title = "功能" })
Tabs.Local:Toggle({
    Title = "开启穿墙",
    Callback = function(v)
        if v then
            noclipConn = RunService.Stepped:Connect(function()
                if LocalPlayer.Character then
                    for _, p in pairs(LocalPlayer.Character:GetDescendants()) do if p:IsA("BasePart") then p.CanCollide = false end end
                end
            end)
        elseif noclipConn then noclipConn:Disconnect() end
    end
})

Tabs.Visuals:Section({ Title = "环境" })
Tabs.Visuals:Toggle({
    Title = "全亮",
    Callback = function(v)
        if v then
            oldLighting = { Brightness = Lighting.Brightness, FogEnd = Lighting.FogEnd, ClockTime = Lighting.ClockTime, Ambient = Lighting.Ambient }
            Lighting.Brightness = 3; Lighting.ClockTime = 14; Lighting.FogEnd = 100000; Lighting.GlobalShadows = false; Lighting.Ambient = Color3.new(1,1,1)
        elseif oldLighting.Brightness then
            Lighting.Brightness = oldLighting.Brightness; Lighting.FogEnd = oldLighting.FogEnd; Lighting.ClockTime = oldLighting.ClockTime; Lighting.Ambient = oldLighting.Ambient
        end
    end
})
Tabs.Visuals:Toggle({ Title = "除雾", Callback = function(v) _G.RemoveFog = v end })

Tabs.Visuals:Section({ Title = "透视" })
local function applyESP(obj, color, text)
    if not obj then return end
    if not obj:FindFirstChild("Highlight") then
        local h = Instance.new("Highlight", obj)
        h.FillColor = color; h.FillTransparency = 0.6; h.OutlineTransparency = 0
    end
end

Tabs.Visuals:Toggle({ Title = "幸存者", Callback = function(v) _G.ESPSurvivor = v end })
Tabs.Visuals:Toggle({ Title = "杀手", Callback = function(v) _G.ESPKiller = v end })
Tabs.Visuals:Toggle({ Title = "发电机", Callback = function(v) _G.ESPGen = v end })
Tabs.Visuals:Toggle({ Title = "保险丝盒", Callback = function(v) _G.ESPFuse = v end })
Tabs.Visuals:Toggle({ Title = "地图门", Callback = function(v) _G.ESPDoor = v end })

Tabs.Survivor:Section({ Title = "功能" })
Tabs.Survivor:Toggle({ Title = "秒修机", Callback = function(v)
    if v then
        genConn = RunService.RenderStepped:Connect(function()
            if LocalPlayer.PlayerGui:FindFirstChild("Gen") then pcall(function() LocalPlayer.PlayerGui.Gen.GeneratorMain.Event:FireServer(true) end) end
        end)
    elseif genConn then genConn:Disconnect() end
end })
Tabs.Survivor:Toggle({ Title = "挡门", Callback = function(v)
    if v then
        dotConn = RunService.RenderStepped:Connect(function()
            local dot = LocalPlayer.PlayerGui:FindFirstChild("Dot")
            if dot and dot:FindFirstChild("Container") then dot.Container.Frame.Position = UDim2.new(0.5, 0, 0.5, 0) end
        end)
    elseif dotConn then dotConn:Disconnect() end
end })
Tabs.Survivor:Toggle({ Title = "自动逃生", Callback = function(v) _G.AutoEscape = v end })
Tabs.Survivor:Toggle({ Title = "自动格挡 (战士身份)", Callback = function(v) _G.AutoParry = v end })

Tabs.Survivor:Section({ Title = "交互" })
Tabs.Survivor:Toggle({ Title = "秒交互", Callback = function(v) activeInstantPrompt = v end })
Tabs.Survivor:Toggle({ Title = "远距离交互", Callback = function(v) activeBigPrompt = v end })

Tabs.Survivor:Section({ Title = "视角" })
Tabs.Survivor:Toggle({ Title = "手动躲避安全区", Callback = function(v)
    local root = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    if not root then return end
    if v then safeLastPos = root.CFrame; root.CFrame = safePart.CFrame + Vector3.new(0,5,0)
    elseif safeLastPos then root.CFrame = safeLastPos; safeLastPos = nil end
end })
Tabs.Survivor:Slider({ Title = "防死阈值", Value = { Min = 10, Max = 80, Default = 30 }, Callback = function(v) healthThreshold = v end })
Tabs.Survivor:Toggle({ Title = "自动残血躲避", Callback = function(v) _G.AntiDeath = v end })
Tabs.Survivor:Toggle({ Title = "查看杀手视角", Callback = function(v)
    viewKiller = v
    if not v then Camera.CameraSubject = LocalPlayer.Character:FindFirstChildOfClass("Humanoid") end
end })

Tabs.Combat:Section({ Title = "攻击增强" })
Tabs.Combat:Slider({ Title = "Hitbox 大小", Value = { Min = 1, Max = 30, Default = 15 }, Callback = function(v) valHitBox = v end })
Tabs.Combat:Toggle({ Title = "修改攻击范围", Callback = function(v) hitBoxExpander = v end })

Tabs.Combat:Section({ Title = "杀手传送" })
Tabs.Combat:Dropdown({ Title = "目标模式", Values = {"最近玩家", "指定玩家"}, Callback = function(v) tpKillMode = v end })
Tabs.Combat:Input({ Title = "指定玩家名", Placeholder = "输入完整名", Callback = function(v) tpKillTarget = v end })
Tabs.Combat:Toggle({ Title = "开启传送杀人", Callback = function(v) _G.TeleportKill = v end })

Tabs.Teleports:Section({ Title = "快捷传送" })
Tabs.Teleports:Button({ Title = "传送到保险丝盒", Callback = function() 
    local box = Workspace:FindFirstChild("MAPS") and Workspace.MAPS["GAME MAP"]:FindFirstChild("FuseBoxes")
    if box then LocalPlayer.Character:MoveTo(box:GetChildren()[1].PrimaryPart.Position) end
end })
Tabs.Teleports:Button({ Title = "传送到发电机", Callback = function() 
    local gens = Workspace:FindFirstChild("MAPS") and Workspace.MAPS["GAME MAP"]:FindFirstChild("Generators")
    if gens then LocalPlayer.Character:MoveTo(gens:GetChildren()[1].PrimaryPart.Position) end
end })
Tabs.Teleports:Button({ Title = "传送到电池", Callback = function() 
    for _, v in pairs(Workspace:GetDescendants()) do if v.Name == "Battery" then LocalPlayer.Character:MoveTo(v.Position) break end end
end })

Tabs.Teleports:Section({ Title = "地图修改" })
Tabs.Teleports:Button({ Title = "强制删除所有的门", Callback = function() 
    local d = Workspace:FindFirstChild("MAPS") and Workspace.MAPS["GAME MAP"]:FindFirstChild("Doors")
    if d then d:Destroy() end
end })
Tabs.Teleports:Button({ Title = "帧率提升", Callback = function() 
    for _, v in pairs(Workspace:GetDescendants()) do if v:IsA("BasePart") then v.CastShadow = false end end
    Lighting.GlobalShadows = false
end })

RunService.Heartbeat:Connect(function()
    local char = LocalPlayer.Character; local root = char and char:FindFirstChild("HumanoidRootPart"); local hum = char and char:FindFirstChildOfClass("Humanoid")
    if not char or not root then return end

    if modifyWalkSpeed then char:SetAttribute("WalkSpeed", valWalkSpeed) end

    if _G.AutoParry and Workspace:FindFirstChild("BoxHandleAdornment", true) then
        local box = Workspace:FindFirstChild("BoxHandleAdornment", true)
        if (box.CFrame.Position - root.Position).Magnitude <= 8 and CanParry then
            CanParry = false; local t = char:FindFirstChildOfClass("Tool"); if t then t:Activate() end
            task.delay(0.5, function() CanParry = true end)
        end
    end

    if _G.AntiDeath and hum.Health < healthThreshold and not antiDeath.teleported then
        antiDeath.teleported = true; antiDeath.lastPos = root.CFrame; root.CFrame = safePart.CFrame + Vector3.new(0,5,0)
    elseif _G.AntiDeath and hum.Health >= 100 and antiDeath.teleported then
        root.CFrame = antiDeath.lastPos; antiDeath.teleported = false
    end

    if _G.TeleportKill then
        local target = nil
        if tpKillMode == "最近玩家" then
            local dist = math.huge; for _, v in pairs(Workspace.PLAYERS.ALIVE:GetChildren()) do
                if v ~= char and v:FindFirstChild("HumanoidRootPart") then
                    local d = (root.Position - v.HumanoidRootPart.Position).Magnitude; if d < dist then dist = d; target = v end
                end
            end
        else target = Workspace.PLAYERS.ALIVE:FindFirstChild(tpKillTarget) end
        if target then root.CFrame = target.HumanoidRootPart.CFrame * CFrame.new(0,0,3) end
    end

    if viewKiller then
        local kFolder = Workspace.PLAYERS:FindFirstChild("KILLER")
        if kFolder and kFolder:GetChildren()[1] then Camera.CameraSubject = kFolder:GetChildren()[1]:FindFirstChildOfClass("Humanoid") end
    end
end)

Workspace.DescendantAdded:Connect(function(child)
    task.wait(0.1)
    if child:IsA("ProximityPrompt") then
        if activeInstantPrompt then child.HoldDuration = 0 end
        if activeBigPrompt then child.MaxActivationDistance = 25 end
    end
    if child:IsA("BoxHandleAdornment") and hitBoxExpander then child.Size = Vector3.new(valHitBox, valHitBox, valHitBox) end
end)