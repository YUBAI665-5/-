local a = game:GetService("Players").LocalPlayer
local b = a.Character or a.CharacterAdded:Wait()
local c = game:GetService("ReplicatedStorage")
local sbns = { c = false, s = false, p = false }

local seeds = {}
local selectseed = ""
for _,v in next, a.PlayerGui.Seed_Shop.Frame.ScrollingFrame:GetChildren() do
    if v.ClassName == "Frame" and not v.Name:find("Padding") then
        table.insert(seeds, v.Name)
    end
end

local gear = {}
local selectgear = ""
for _,v in next, a.PlayerGui.Gear_Shop.Frame.ScrollingFrame:GetChildren() do
    if v.ClassName == "Frame" and not v.Name:find("_") then
        table.insert(gear, v.Name)
    end
end

hookfunction(require(c.Modules.PlayerLuck).GetLuck, function() return math.huge end)
hookfunction(require(c.Modules.PlayerLuck).GetModifiers, function()
    return {{ Name = "Fake_Luck", Modifier = math.huge }}
end)
for _,v in ipairs(require(c.Data.SessionTimeLuckData).Timer) do
    if v.Luck then v.Luck = math.huge end
end
hookfunction(require(c.Modules.SessionTimeLuckController).GetCurrentLuck, function() return math.huge end)

local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)

local MainSection = Window:Section({ Title = "主要菜单", Opened = true })
local Main = MainSection:Tab({Title = "主要功能", Icon = "sword"})
Window:SelectTab(1)
Main:Toggle({
    Title = "自动收集",
    Value = false,
    Callback = function(state)
        sbns.c = state
        spawn(function()
            while wait() and sbns.c do
                pcall(function()
                    for _, e in pairs(workspace.Farm:GetChildren()) do
                        if e:FindFirstChild("Important") and e.Important.Data.Owner.Value == a.Name then
                            for _, g in ipairs(e.Important.Plants_Physical:GetDescendants()) do
                                if g:IsA("ProximityPrompt") then
                                    b.Humanoid:MoveTo(g.Parent.Position)
                                    fireproximityprompt(g)
                                end
                            end
                        end
                    end
                end)
            end
        end)
    end
})

Main:Toggle({
    Title = "自动售卖",
    Value = false,
    Callback = function(state)
        sbns.s = state
        spawn(function()
            while wait() and sbns.s do
                if #a.Backpack:GetChildren() > 20 then
                    local h = b.HumanoidRootPart.CFrame
                    b.HumanoidRootPart.CFrame = workspace.NPCS["Sell Stands"]["Shop Stand"].CFrame * CFrame.new(0, 0, 3)
                    wait(0.5)
                    c.GameEvents.Sell_Item:FireServer()
                    c.GameEvents.Sell_Inventory:FireServer()
                    wait(1)
                    b.HumanoidRootPart.CFrame = h
                end
            end
        end)
    end
})

Main:Toggle({
    Title = "自动种植",
    Value = false,
    Callback = function(state)
        sbns.p = state
        spawn(function()
            while wait() and sbns.p do
                pcall(function()
                    local seedType, tool
                    local containers = {b, a.Backpack}
                    for _, cont in ipairs(containers) do
                        for _, i in ipairs(cont:GetChildren()) do
                            if i:IsA("Tool") and i.Name:find("Seed") then
                                seedType = i.Name:match("^(.-) Seed"); tool = i; break
                            end
                        end
                        if tool then break end
                    end
                    if tool and seedType then
                        if tool.Parent == a.Backpack then b.Humanoid:EquipTool(tool) end
                        c.GameEvents.Plant_RE:FireServer(Vector3.new(math.floor(b.HumanoidRootPart.Position.X), 0.1, math.floor(b.HumanoidRootPart.Position.Z)), seedType)
                    end
                end)
            end
        end)
    end
})

Main:Divider()

Main:Dropdown({
    Title = "选择种子",
    Values = seeds,
    Callback = function(value) selectseed = value end
})

local SeedInfo = Main:Paragraph({ Title = "种子信息", Desc = "等待选择..." })

Main:Button({
    Title = "购买种子",
    Callback = function()
        if selectseed ~= "" then c.GameEvents.BuySeedStock:FireServer("Tier 1", selectseed) end
    end
})

Main:Dropdown({
    Title = "选择工具",
    Values = gear,
    Callback = function(value) selectgear = value end
})

local GearInfo = Main:Paragraph({ Title = "工具信息", Desc = "等待选择..." })

Main:Button({
    Title = "购买工具",
    Callback = function()
        if selectgear ~= "" then c.GameEvents.BuyGearStock:FireServer(selectgear) end
    end
})

task.spawn(function()
    while wait(1) do
        if selectseed ~= "" then
            local f = a.PlayerGui.Seed_Shop.Frame.ScrollingFrame:FindFirstChild(selectseed)
            if f then SeedInfo:SetDesc("价格: " .. f.Main_Frame.Cost_Text.Text .. " | 数量: " .. f.Main_Frame.Stock_Text.Text) end
        end
        if selectgear ~= "" then
            local f = a.PlayerGui.Gear_Shop.Frame.ScrollingFrame:FindFirstChild(selectgear)
            if f then GearInfo:SetDesc("价格: " .. f.Main_Frame.Cost_Text.Text .. " | 数量: " .. f.Main_Frame.Stock_Text.Text) end
        end
    end
end)