local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local localPlayer = Players.LocalPlayer
local goldBlockVal = localPlayer:WaitForChild("Data"):WaitForChild("GoldBlock")
local goldVal = localPlayer.Data:WaitForChild("Gold")
local claimRiverResultsGoldEvent = workspace:WaitForChild("ClaimRiverResultsGold")
local stagePositions = {}
local chestTrigger, chestTriggerOriginCFrame
local roundCount = 0 

for _, stage in workspace:WaitForChild("BoatStages"):WaitForChild("NormalStages"):GetChildren() do
    local index = tonumber(stage.Name:match("%d+"))
    if index then stagePositions[index] = stage.DarknessPart.CFrame end
    if stage.Name == "TheEnd" then
        chestTrigger = stage.GoldenChest.Trigger
        chestTriggerOriginCFrame = chestTrigger.CFrame
    end
end

local goldFarming = false
local candyFarming = false
local connections = {}
local statusOverlay 

local WindUI = loadstring(game:HttpGet("https://raw.githubusercontent.com/Yisan886/Aero/refs/heads/main/ui.lua.txt"))()

WindUI:AddTheme({
    Name = "My Theme",
    Accent = Color3.fromHex("#18181b"),
    Background = Color3.fromHex("#101010"),
    Outline = Color3.fromHex("#FFFFFF"),
    Text = Color3.fromHex("#FFFFFF"),
    Placeholder = Color3.fromHex("#7a7a7a"),
    Button = Color3.fromHex("#52525b"),
    Icon = Color3.fromHex("#a1a1aa"),
})

local Window = WindUI:CreateWindow({
    Title = "Aero      ",
    Folder = "Aero",
    SideBarWidth = 180,
    Background = "https://chaton-images.s3.us-east-2.amazonaws.com/GHn9L9UJLf0XcVNyCpbG72D0rmNmBEWndPkh6CjJNya8GLnWzz1vImvt8wlJSBwv_2700x1519x1393696.jpeg", -- video 
    BackgroundImageTransparency = 0.5,
    OpenButton = {
        Title = "打开脚本",
        CornerRadius = UDim.new(1, 0),
        StrokeThickness = 3,
        Enabled = true,
        Draggable = true,
        OnlyMobile = false,
        Scale = 0.9,
        Color = ColorSequence.new(
            Color3.fromHex("#30FF6A"),
            Color3.fromHex("#e7ff2f")
        ),
    },
    Topbar = {
        Height = 44,
        ButtonsType = "Mac",
    },
})

Window:Tag({
    Title = "V1.03",
    Color = Color3.fromHex("00CED1"),
    Radius = 2,
})

Window:Tag({
    Title = "伊散",
    Icon = "crown",
    Color = Color3.fromHex("FFD700"),
    Radius = 2,
})

Window:Tag({
    Title = "苏达",
    Icon = "square-chevron-right",
    Color = Color3.fromHex("#30ff6a"),
    Radius = 2,
})

local COLOR_SCHEMES = {
    ["彩虹颜色"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,    Color3.fromHex("FF0000")),
        ColorSequenceKeypoint.new(0.16, Color3.fromHex("FFA500")),
        ColorSequenceKeypoint.new(0.33, Color3.fromHex("FFFF00")),
        ColorSequenceKeypoint.new(0.5,  Color3.fromHex("00FF00")),
        ColorSequenceKeypoint.new(0.66, Color3.fromHex("0000FF")),
        ColorSequenceKeypoint.new(0.83, Color3.fromHex("4B0082")),
        ColorSequenceKeypoint.new(1,    Color3.fromHex("EE82EE"))
    }), "palette"},

    ["绿黄渐变"] = {ColorSequence.new({
        ColorSequenceKeypoint.new(0,   Color3.fromHex("30FF6A")),
        ColorSequenceKeypoint.new(0.5, Color3.fromHex("a8ff00")),
        ColorSequenceKeypoint.new(1,   Color3.fromHex("e7ff2f"))
    }), "waves"},
}

local borderAnimation
local animationSpeed = 5

local function createRainbowBorder(window, colorScheme)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end

    local existingStroke = mainFrame:FindFirstChild("RainbowStroke")
    if existingStroke then existingStroke:Destroy() end

    if not mainFrame:FindFirstChildOfClass("UICorner") then
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 16)
        corner.Parent = mainFrame
    end

    local rainbowStroke = Instance.new("UIStroke")
    rainbowStroke.Name = "RainbowStroke"
    rainbowStroke.Thickness = 2
    rainbowStroke.Color = Color3.new(1, 1, 1)
    rainbowStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    rainbowStroke.LineJoinMode = Enum.LineJoinMode.Round
    rainbowStroke.Parent = mainFrame

    local glowEffect = Instance.new("UIGradient")
    glowEffect.Name = "GlowEffect"
    local schemeData = COLOR_SCHEMES[colorScheme or "彩虹颜色"]
    glowEffect.Color = schemeData and schemeData[1] or COLOR_SCHEMES["彩虹颜色"][1]
    glowEffect.Rotation = 0
    glowEffect.Parent = rainbowStroke

    return rainbowStroke
end

local function startBorderAnimation(window, speed)
    local mainFrame = window.UIElements.Main
    if not mainFrame then return nil end
    local rainbowStroke = mainFrame:FindFirstChild("RainbowStroke")
    if not rainbowStroke then return nil end
    local glowEffect = rainbowStroke:FindFirstChild("GlowEffect")
    if not glowEffect then return nil end

    return game:GetService("RunService").Heartbeat:Connect(function()
        if not rainbowStroke or rainbowStroke.Parent == nil then return end
        glowEffect.Rotation = (tick() * speed * 10) % 360
    end)
end

local rainbowStroke = createRainbowBorder(Window, "彩虹颜色")
if rainbowStroke then
    borderAnimation = startBorderAnimation(Window, animationSpeed)
end

local Lighting = game:GetService("Lighting")
local TweenServiceBlur = game:GetService("TweenService")

local blur = Lighting:FindFirstChildOfClass("BlurEffect")
if not blur then
    blur = Instance.new("BlurEffect")
    blur.Size = 0
    blur.Parent = Lighting
end

task.spawn(function()
    local wasOpen = false
    while true do
        task.wait(0.1)
        local mainFrame = Window.UIElements and Window.UIElements.Main
        local isOpen = mainFrame and mainFrame.Visible or false
        
        if isOpen ~= wasOpen then
            wasOpen = isOpen
            TweenServiceBlur:Create(blur, TweenInfo.new(0.3), {
                Size = isOpen and 20 or 0
            }):Play()
        end
    end
end)
local CombatTab = Window:Tab({ Title = '功能', Icon = 'swords' })
local StatsTab = Window:Tab({ Title = '统计', Icon = 'bar-chart' })
Window:SelectTab(1)
local statsPara = StatsTab:Paragraph({
    Title = "统计",
    Desc = "已刷总轮数: 0\n当前金币: 加载中...\n当前金块: 加载中..."
})

StatsTab:Button({
    Title = "重置轮数",
    Callback = function()
        roundCount = 0
        WindUI:Notify({Title = "统计", Content = "轮数已清零", Duration = 2})
    end
})

local function updateOverlay(text)
    if not statusOverlay then
        statusOverlay = Drawing.new("Text")
        statusOverlay.Outline = true
        statusOverlay.Color = Color3.new(1, 1, 1)
        statusOverlay.Position = Vector2.new(20, 40)
        statusOverlay.Size = 18
        statusOverlay.Visible = true
    end
    statusOverlay.Text = text
end

CombatTab:Toggle({
    Title = "自动农场",
    Value = false,
    Callback = function(enabled)
        goldFarming = enabled
        if not enabled then
            for _, c in pairs(connections) do c:Disconnect() end
            if statusOverlay then statusOverlay.Visible = false end
            return
        end
        
        local startTime = time()
        if statusOverlay then statusOverlay.Visible = true end

        table.insert(connections, RunService.Heartbeat:Connect(function()
            local char = localPlayer.Character
            local root = char and char:FindFirstChild("HumanoidRootPart")
            if not root then return end

            if _G.AtEnd then
                pcall(firetouchinterest, chestTrigger, root, 0)
            end
            
            root.CFrame = _G.TargetPos or stagePositions[1]
            root.Velocity = Vector3.zero
            
            updateOverlay("塔菲喵 造船挂机中...\n已运行: " .. math.floor(time() - startTime) .. "s\n已完成: " .. roundCount .. " 轮")
            statsPara:SetDesc(string.format("已刷总轮数: %d\n当前金币: %d\n当前金块: %d", roundCount, goldVal.Value, goldBlockVal.Value))
        end))

        table.insert(connections, localPlayer.CharacterRemoving:Connect(function()
            roundCount = roundCount + 1
            _G.AtEnd = false
            claimRiverResultsGoldEvent:FireServer()
        end))

        task.spawn(function()
            while goldFarming do
                for i = 1, 9 do
                    if not goldFarming then break end
                    _G.TargetPos = stagePositions[i]
                    task.wait(2) 
                end
                _G.AtEnd = true
                task.wait(3) 
                while _G.AtEnd and goldFarming do task.wait() end
            end
        end)
    end
})

CombatTab:Toggle({
    Title = "自动刷糖果",
    Value = false,
    Callback = function(enabled)
        candyFarming = enabled
        if enabled then
            task.spawn(function()
                while candyFarming do
                    task.wait(0.1)
                    local char = localPlayer.Character
                    local root = char and char:FindFirstChild("HumanoidRootPart")
                    if root and workspace:FindFirstChild("Houses") then
                        for _, house in pairs(workspace.Houses:GetChildren()) do
                            local door = house:FindFirstChild("Door") and house.Door:FindFirstChild("DoorInnerTouch")
                            if door then
                                pcall(firetouchinterest, root, door, 0)
                            end
                        end
                    end
                end
            end)
            WindUI:Notify({Title = "功能开启", Content = "开始自动收集全图糖果", Duration = 3})
        end
    end
})